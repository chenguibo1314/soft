package com.baidu.disconf.client.core.filetype.impl;

import java.util.Map;

import com.baidu.disconf.client.core.filetype.DisconfFileTypeProcessor;

/**
 * Created by knightliao on 15/1/21.
 * <p/>
 * 任意文件的处理
 */
public class DisconfAnyFileProcessorImpl implements DisconfFileTypeProcessor {

    @Override
    public Map<String, Object> getKvMap(String fileName) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

}
