package com.baidu.disconf.client.addons.properties;

/**
 *
 */
public interface ReconfigurableBean {

    void reloadConfiguration() throws Exception;
}
