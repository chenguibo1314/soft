package com.baidu.disconf.client.core.filetype.impl;

import java.util.Map;

import com.baidu.disconf.client.core.filetype.DisconfFileTypeProcessor;

/**
 * xml 处理器
 *
 * @author knightliao
 */
public class DisconfXmlProcessorImpl implements DisconfFileTypeProcessor {

    @Override
    public Map<String, Object> getKvMap(String fileName) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

}
