package com.baidu.disconf.client.test.store;

import com.baidu.disconf.client.test.common.BaseSpringTestCase;

/**
 * @author liaoqiqi
 * @version 2014-6-16
 */
public class DisconfStoreMgrTestCase extends BaseSpringTestCase {

}
