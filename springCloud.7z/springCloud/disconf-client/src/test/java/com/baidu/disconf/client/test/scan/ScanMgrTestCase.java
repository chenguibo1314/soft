package com.baidu.disconf.client.test.scan;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.baidu.disconf.client.test.common.BaseSpringTestCase;

/**
 * @author liaoqiqi
 * @version 2014-7-30
 */
public class ScanMgrTestCase extends BaseSpringTestCase {

    protected static final Logger LOGGER = LoggerFactory.getLogger(ScanMgrTestCase.class);

    @Test
    public void scan() {

    }
}
