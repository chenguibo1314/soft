package com.baidu.disconf.client.test.config;

import com.baidu.disconf.client.test.common.BaseSpringTestCase;

/**
 * @author liaoqiqi
 * @version 2014-6-17
 */
public class ConfigMgrTestCase extends BaseSpringTestCase {

}
