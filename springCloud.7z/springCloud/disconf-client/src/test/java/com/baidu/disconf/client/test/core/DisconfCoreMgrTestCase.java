package com.baidu.disconf.client.test.core;

import com.baidu.disconf.client.test.common.BaseSpringTestCase;

/**
 * @author liaoqiqi
 * @version 2014-6-17
 */
public class DisconfCoreMgrTestCase extends BaseSpringTestCase {

}
