disconf-client
=======

在disconf-client 2.6.36的基础上进行修改，以支持springboot2（spring5）


