package com.fcbox.authority.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/3/21
 **/
@Configuration
public class RocketmqConfig {

}
