package com.fcbox.authority.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/3/27
 **/
@FeignClient(name="service-provider")
public interface ServiceProviderClient {

    @RequestMapping(value = "get",method = RequestMethod.GET)
    Integer getR(@RequestParam(value = "a") Integer a,@RequestParam(value = "b") Integer b);

}
