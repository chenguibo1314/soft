package com.fcbox.authority;

import com.spring4all.swagger.EnableSwagger2Doc;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import java.util.Collections;
import java.util.concurrent.CountDownLatch;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/3/21
 **/
@EnableSwagger2Doc
@SpringBootApplication
@Slf4j
@EnableEurekaClient
@EnableFeignClients
public class AuthorityWebApplication {

    /**
     * @param builder
     * @return
     */
    private static SpringApplicationBuilder configureSpringBuilder(SpringApplicationBuilder builder) {
        builder.application().addPrimarySources(Collections.singletonList(AuthorityWebApplication.class));
        return builder.sources(AuthorityWebApplication.class);
    }

    public static void main(String[] args) throws InterruptedException {
        configureSpringBuilder(new SpringApplicationBuilder())
                .application()
                .run(args);

        new CountDownLatch(1).await();
    }

}

