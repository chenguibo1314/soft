package com.fcbox.authority.controller;

import com.fcbox.apimodel.domain.ApiResponseResult;
import com.fcbox.apimodel.response.BaseResponse;
import com.fcbox.appmodel.domain.result.ModelResult;
import com.fcbox.authority.biz.entity.SystemAuthPosition;
import com.fcbox.authority.biz.entity.UserSystemAuth;
import com.fcbox.authority.biz.returnCode.AuthApiReturnCodeMap;
import com.fcbox.authority.biz.service.inner.interfaces.AccessSystemService;
import com.fcbox.authority.biz.service.inner.interfaces.SystemAuthPositionService;
import com.fcbox.authority.biz.service.inner.interfaces.UserSystemAuthService;
import com.fcbox.authority.biz.util.CalculateAuthUtil;
import com.fcbox.authority.client.interfaces.UserSystemAuthClient;
import com.fcbox.authority.client.vo.request.UserSystemAuthVo;
import com.fcbox.authority.client.vo.response.UserSystemAuthResultVo;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/3/22
 **/
@Api(tags="userAuth")
@Slf4j
@RestController
public class UserSystemAuthController extends BaseResponse implements UserSystemAuthClient {

    @Autowired
    private UserSystemAuthService userSystemAuthService;

    @Autowired
    private SystemAuthPositionService systemAuthPositionService;

    @Override
    public ApiResponseResult updateUserSystemAuth(UserSystemAuthVo userSystemAuthVo) {
        ApiResponseResult result = new ApiResponseResult();
        if(StringUtils.isBlank(userSystemAuthVo.getUserAccount()) || StringUtils.isBlank(userSystemAuthVo.getSystemCode())
                || userSystemAuthVo.getForbidOrNot() == null || StringUtils.isBlank(userSystemAuthVo.getUpdateEmp())){
            return result.failure(AuthApiReturnCodeMap.failureParams,AuthApiReturnCodeMap.getDescByKey(AuthApiReturnCodeMap.failureParams));
        }
        userSystemAuthService.updateUserSystemAuth(userSystemAuthVo);
        return result;
    }

    @Override
    public ApiResponseResult selectUserAllSystemAuth(String userAccount) {
        ApiResponseResult result = new ApiResponseResult();
        if(StringUtils.isBlank(userAccount)){
            return result.failure(AuthApiReturnCodeMap.failureParams,AuthApiReturnCodeMap.getDescByKey(AuthApiReturnCodeMap.failureParams));
        }
        UserSystemAuthResultVo userSystemAuthResultVo = new UserSystemAuthResultVo();
        userSystemAuthResultVo.setUserAccount(userAccount);
        result.setData(userSystemAuthResultVo);
        UserSystemAuth userSystemAuth = userSystemAuthService.selectByUserAccount(userAccount).getModel();
        Map<String, SystemAuthPosition> systemAuthPositionMap = systemAuthPositionService.selectAllSystemAuthPosition().getModel();
        if(userSystemAuth != null && !CollectionUtils.isEmpty(systemAuthPositionMap)){
            for(String systemCode : systemAuthPositionMap.keySet()){
                if(CalculateAuthUtil.hasSystemAuth(userSystemAuth.getAuthData(),systemAuthPositionMap.get(systemCode).getAuthPosition())){
                    userSystemAuthResultVo.getSystemAuths().put(systemCode,true);
                }else{
                    userSystemAuthResultVo.getSystemAuths().put(systemCode,false);
                }
            }
        }
        return result;
    }

    @Override
    public ApiResponseResult userAuthentication(UserSystemAuthVo userSystemAuthVo) {
        ApiResponseResult result = new ApiResponseResult();
        if(StringUtils.isBlank(userSystemAuthVo.getUserAccount()) || StringUtils.isBlank(userSystemAuthVo.getSystemCode())){
            return result.failure(AuthApiReturnCodeMap.failureParams,AuthApiReturnCodeMap.getDescByKey(AuthApiReturnCodeMap.failureParams));
        }
        UserSystemAuth userSystemAuth = userSystemAuthService.selectByUserAccount(userSystemAuthVo.getUserAccount()).getModel();
        ModelResult<SystemAuthPosition>  systemAuthPositionResult = systemAuthPositionService.selectAuthPositionBySystemCode(userSystemAuthVo.getSystemCode());
        if(systemAuthPositionResult.isFailure()){
            return result.failure(systemAuthPositionResult.getErrorCode(),systemAuthPositionResult.getErrorMsg());
        }
        SystemAuthPosition systemAuthPosition = systemAuthPositionResult.getModel();
        if(CalculateAuthUtil.hasSystemAuth(userSystemAuth.getAuthData(),systemAuthPosition.getAuthPosition())){
            result.setData(true);
        }else{
            result.setData(false);
        }
        return result;
    }
}
