package com.fcbox.authority.controller;

import com.fcbox.apimodel.domain.ApiResponseResult;
import com.fcbox.apimodel.response.BaseResponse;
import com.fcbox.authority.biz.service.inner.interfaces.AccessSystemService;
import com.fcbox.authority.client.interfaces.AccessSystemClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**   @RequestMapping不能注解在类上，否则调用方通过client调用不了
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/3/22
 **/
@RestController
@Slf4j
//@RequestMapping("/accessSystem")
public class AccessSystemController extends BaseResponse implements AccessSystemClient {

    @Autowired
    private AccessSystemService accessSystemService;

    @Override
    public ApiResponseResult selectAll() {
        return success(accessSystemService.selectAllNotDelSystemInfo().getModel());
    }

}
