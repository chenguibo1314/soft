package com.fcbox.authority.biz.service.inner.impl;

import com.fcbox.appmodel.domain.result.ModelResult;
import com.fcbox.authority.biz.entity.SystemAuthPosition;
import com.fcbox.authority.biz.entity.SystemAuthPositionExample;
import com.fcbox.authority.biz.mapper.AccessSystemInfoMapper;
import com.fcbox.authority.biz.mapper.SystemAuthPositionMapper;
import com.fcbox.authority.biz.returnCode.AuthApiReturnCodeMap;
import com.fcbox.authority.biz.service.inner.interfaces.SystemAuthPositionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/12
 **/
@Service
public class SystemAuthPositionServiceImpl implements SystemAuthPositionService {

    @Autowired
    private SystemAuthPositionMapper systemAuthPositionMapper;

    @Override
    public ModelResult<SystemAuthPosition> selectAuthPositionBySystemCode(String systemCode) {
        ModelResult<SystemAuthPosition> result= new ModelResult<>();
        SystemAuthPositionExample example = new SystemAuthPositionExample();
        example.createCriteria().andSystemCodeEqualTo(systemCode);
        List<SystemAuthPosition> systemAuthPositions = systemAuthPositionMapper.selectByExample(example);
        if(CollectionUtils.isEmpty(systemAuthPositions)){
            return result.withError(AuthApiReturnCodeMap.systemAuthNotFound,AuthApiReturnCodeMap.getDescByKey(AuthApiReturnCodeMap.systemAuthNotFound));
        }
        return result.withModel(systemAuthPositions.get(0));
    }

    @Override
    public ModelResult<Map<String, SystemAuthPosition>> selectAllSystemAuthPosition() {
        ModelResult<Map<String, SystemAuthPosition>> result= new ModelResult<>();
        SystemAuthPositionExample example = new SystemAuthPositionExample();
        List<SystemAuthPosition> systemAuthPositions = systemAuthPositionMapper.selectByExample(example);
        if(Optional.ofNullable(systemAuthPositions).isPresent()) {
            result.withModel(systemAuthPositions.stream().collect(Collectors.toMap(SystemAuthPosition::getSystemCode, systemAuthPosition -> systemAuthPosition)));
        }
        return result;
    }
}
