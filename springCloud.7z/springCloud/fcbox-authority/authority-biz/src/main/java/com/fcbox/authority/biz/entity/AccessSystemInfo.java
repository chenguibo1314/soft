package com.fcbox.authority.biz.entity;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;

@Data
public class AccessSystemInfo {
    private Integer id;

    private String systemName;

    private String systemCode;

    private String photoUrl;

    private Integer status;

    private String createEmp;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTm;

    private String updateEmp;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTm;

    private Integer delFlag;
}