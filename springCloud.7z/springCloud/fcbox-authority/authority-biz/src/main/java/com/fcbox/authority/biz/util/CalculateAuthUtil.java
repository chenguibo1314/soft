package com.fcbox.authority.biz.util;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/12
 **/
public class CalculateAuthUtil {
    private final static int two = 2;

    /**
     * 判断用户是否有目标系统权限
     * @param purviewValue 用户的权限总和值
     * @param authPosition 系统权限位
     * @return
     */
    public static boolean hasSystemAuth(long purviewValue,int authPosition){
        return (purviewValue&(long)Math.pow(two,authPosition))
                == (long)Math.pow(two,authPosition);
    }

    /**
     * 获取用户目标系统禁用后的权限总和值
     * @param purviewValue 用户的权限总和值
     * @param authPosition 系统权限位
     * @return
     */
    public static long getForbidSystemAuthValue(long purviewValue,int authPosition){
        return purviewValue - (long)Math.pow(two,authPosition);
    }

    /**
     * 获取用户目标系统启用后的权限总和值
     * @param purviewValue 用户的权限总和值
     * @param authPosition 系统权限位
     * @return
     */
    public static long getStartSystemAuthValue(long purviewValue,int authPosition){
        return purviewValue + (long)Math.pow(two,authPosition);
    }
}
