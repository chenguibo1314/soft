package com.fcbox.authority.biz.service.inner.impl.biz1;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/3
 **/
public class Demo {
}
