package com.fcbox.authority.biz.service.inner.impl;

import com.fcbox.appmodel.domain.result.ModelResult;
import com.fcbox.authority.biz.entity.SystemAuthPosition;
import com.fcbox.authority.biz.entity.SystemAuthPositionExample;
import com.fcbox.authority.biz.entity.UserSystemAuth;
import com.fcbox.authority.biz.entity.UserSystemAuthExample;
import com.fcbox.authority.biz.mapper.AccessSystemInfoMapper;
import com.fcbox.authority.biz.mapper.SystemAuthPositionMapper;
import com.fcbox.authority.biz.mapper.UserSystemAuthMapper;
import com.fcbox.authority.biz.returnCode.AuthApiReturnCodeMap;
import com.fcbox.authority.biz.service.inner.interfaces.UserSystemAuthService;
import com.fcbox.authority.biz.util.CalculateAuthUtil;
import com.fcbox.authority.client.vo.request.UserSystemAuthVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/12
 **/
@Slf4j
@Service
public class UserSystemAuthServiceImpl implements UserSystemAuthService {

    /**
     * 60个系统启用总权限
     */
    public static final long TOTAL_PURVIEW_VALUE = 1152921504606846975L;
    /**
     * 超级管理员
     */
    public static final String SYSTEM_MANAGER = "system";
    @Autowired
    private UserSystemAuthMapper userSystemAuthMapper;

    @Autowired
    private SystemAuthPositionMapper systemAuthPositionMapper;

    @Override
    public ModelResult<Void> updateUserSystemAuth(UserSystemAuthVo userSystemAuthVo) {
        ModelResult<Void> result = new ModelResult<>();
        UserSystemAuth userSystemAuthData = this.selectByUserAccount(userSystemAuthVo.getUserAccount()).getModel();
        SystemAuthPositionExample systemAuthPositionExample = new SystemAuthPositionExample();
        systemAuthPositionExample.createCriteria().andSystemCodeEqualTo(userSystemAuthVo.getSystemCode());
        SystemAuthPosition systemAuthPosition = systemAuthPositionMapper.selectByExample(systemAuthPositionExample).get(0);
        if(systemAuthPosition == null){
            result.withError(AuthApiReturnCodeMap.systemAuthNotFound,AuthApiReturnCodeMap.getDescByKey(AuthApiReturnCodeMap.systemAuthNotFound));
            return result;
        }
        if(userSystemAuthData != null){
            if(userSystemAuthVo.getForbidOrNot()){
                if(CalculateAuthUtil.hasSystemAuth(userSystemAuthData.getAuthData(),systemAuthPosition.getAuthPosition())){
                    userSystemAuthData.setAuthData(CalculateAuthUtil.getForbidSystemAuthValue(userSystemAuthData.getAuthData(),systemAuthPosition.getAuthPosition()));
                }
            }else{
                if(!CalculateAuthUtil.hasSystemAuth(userSystemAuthData.getAuthData(),systemAuthPosition.getAuthPosition())){
                    userSystemAuthData.setAuthData(CalculateAuthUtil.getStartSystemAuthValue(userSystemAuthData.getAuthData(),systemAuthPosition.getAuthPosition()));
                }
            }
            userSystemAuthMapper.updateByPrimaryKeySelective(userSystemAuthData);
        }else{
            userSystemAuthData =initUserSystemAuthData(userSystemAuthVo.getUserAccount());
            if(userSystemAuthVo.getForbidOrNot()){
                userSystemAuthData.setAuthData(CalculateAuthUtil.getForbidSystemAuthValue(TOTAL_PURVIEW_VALUE,systemAuthPosition.getAuthPosition()));
            }
            userSystemAuthData.setUpdateTm(LocalDateTime.now());
            userSystemAuthData.setUpdateEmp(userSystemAuthVo.getUpdateEmp());
            userSystemAuthMapper.updateByPrimaryKeySelective(userSystemAuthData);
        }
        return result;
    }

    /**
     * 用户各系统启用权限不好一次性初始化，采用初次访问初始化方式
     * @param userAccount
     * @return
     */
    private UserSystemAuth initUserSystemAuthData(String userAccount) {
        UserSystemAuth userSystemAuthData = new UserSystemAuth();
        userSystemAuthData.setUserAccount(userAccount);
        userSystemAuthData.setAuthData(TOTAL_PURVIEW_VALUE);
        userSystemAuthData.setCreateTm(LocalDateTime.now());
        userSystemAuthData.setCreateEmp(SYSTEM_MANAGER);
        userSystemAuthMapper.insertSelective(userSystemAuthData);
        return userSystemAuthData;
    }

    @Override
    public ModelResult<UserSystemAuth> selectByUserAccount(String userAccount) {
        ModelResult<UserSystemAuth> result = new ModelResult<>();
        UserSystemAuthExample example = new UserSystemAuthExample();
        example.createCriteria().andUserAccountEqualTo(userAccount);
        List<UserSystemAuth> userSystemAuths= userSystemAuthMapper.selectByExample(example);
        UserSystemAuth userSystemAuthData = null;
        if(CollectionUtils.isEmpty(userSystemAuths)){
            userSystemAuthData = initUserSystemAuthData(userAccount);
        }else{
            userSystemAuthData = userSystemAuths.get(0);
        }
        return result.withModel(userSystemAuthData);
    }
}
