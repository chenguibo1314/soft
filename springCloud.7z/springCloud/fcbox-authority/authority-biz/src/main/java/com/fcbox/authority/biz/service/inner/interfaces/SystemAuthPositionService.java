package com.fcbox.authority.biz.service.inner.interfaces;

import com.fcbox.appmodel.domain.result.ModelResult;
import com.fcbox.authority.biz.entity.SystemAuthPosition;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Service;

import java.util.Map;


public interface SystemAuthPositionService {

    ModelResult<SystemAuthPosition> selectAuthPositionBySystemCode(String systemCode);

    ModelResult<Map<String,SystemAuthPosition>> selectAllSystemAuthPosition();


}