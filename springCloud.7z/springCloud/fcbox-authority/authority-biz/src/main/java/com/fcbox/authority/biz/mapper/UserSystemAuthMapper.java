package com.fcbox.authority.biz.mapper;

import com.fcbox.authority.biz.entity.UserSystemAuth;
import com.fcbox.authority.biz.entity.UserSystemAuthExample;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserSystemAuthMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(UserSystemAuth record);

    int insertSelective(UserSystemAuth record);

    List<UserSystemAuth> selectByExample(UserSystemAuthExample example);

    UserSystemAuth selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(UserSystemAuth record);

    int updateByPrimaryKey(UserSystemAuth record);
}