package com.fcbox.authority.biz.service.inner.interfaces;

import com.fcbox.appmodel.domain.result.ModelResult;
import com.fcbox.authority.biz.entity.AccessSystemInfo;

import java.util.List;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/8
 **/
public interface AccessSystemService {
    ModelResult<List<AccessSystemInfo>> selectAllNotDelSystemInfo();

}
