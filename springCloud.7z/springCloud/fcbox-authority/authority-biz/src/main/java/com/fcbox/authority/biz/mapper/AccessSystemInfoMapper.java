package com.fcbox.authority.biz.mapper;

import com.fcbox.authority.biz.entity.AccessSystemInfo;
import com.fcbox.authority.biz.entity.AccessSystemInfoExample;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface AccessSystemInfoMapper {

    int insert(AccessSystemInfo record);

    int insertSelective(AccessSystemInfo record);

    List<AccessSystemInfo> selectByExample(AccessSystemInfoExample example);

    AccessSystemInfo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(AccessSystemInfo record);

    int updateByPrimaryKey(AccessSystemInfo record);
}