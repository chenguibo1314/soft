package com.fcbox.authority.biz.returnCode;

import com.fcbox.apimodel.map.ApiReturnCodeMap;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/15
 **/
public class AuthApiReturnCodeMap extends ApiReturnCodeMap {
    /**
     * 用户系统启用信息不存在
     */
    public static final String userSystemAuthNOtFound = "00101001";
    /**
     * 系统启用信息不存在
     */
    public static final String systemAuthNotFound = "00101001";
    /**
     * 请求参数错误
     */
    public static final String failureParams = "00000001";
    /**
     * 请求参数错误
     */
    public static final String repeatSubmitFailureParams = "00000002";


    public static final Map<String, String> authApiReturnCodeMap = new LinkedHashMap<>();

    static {
        authApiReturnCodeMap.put(userSystemAuthNOtFound, "用户系统启用信息不存在");
        authApiReturnCodeMap.put(systemAuthNotFound, "失败");
    }

    /**
     * 根据key返回描述信息
     *
     * @param key
     * @return
     */
    public static String getDescByKey(String key) {
        return authApiReturnCodeMap.get(key);
    }
}
