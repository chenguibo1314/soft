package com.fcbox.authority.biz.service.inner.impl;

import com.fcbox.appmodel.domain.result.ModelResult;
import com.fcbox.authority.biz.entity.AccessSystemInfo;
import com.fcbox.authority.biz.entity.AccessSystemInfoExample;
import com.fcbox.authority.biz.mapper.AccessSystemInfoMapper;
import com.fcbox.authority.biz.service.inner.interfaces.AccessSystemService;
import com.fcbox.authority.client.map.DelFlagMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/8
 **/
@Service
public class AccessSystemServiceImpl implements AccessSystemService {

    @Autowired
    private AccessSystemInfoMapper accessSystemInfoMapper;

    @Override
    public ModelResult<List<AccessSystemInfo>> selectAllNotDelSystemInfo() {
        ModelResult<List<AccessSystemInfo>> result = new ModelResult<>();
        AccessSystemInfoExample example = new AccessSystemInfoExample();
        example.createCriteria().andDelFlagEqualTo(DelFlagMap.unDel);
        return result.withModel(accessSystemInfoMapper.selectByExample(example));
    }
}
