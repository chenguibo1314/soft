package com.fcbox.authority.biz.entity;

import lombok.Data;

@Data
public class SystemAuthPosition {
    private Integer id;

    private String systemCode;

    private String systemName;

    private Integer authPosition;
}