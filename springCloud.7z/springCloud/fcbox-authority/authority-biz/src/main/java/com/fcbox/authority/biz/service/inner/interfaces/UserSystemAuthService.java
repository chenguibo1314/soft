package com.fcbox.authority.biz.service.inner.interfaces;

import com.fcbox.appmodel.domain.result.ModelResult;
import com.fcbox.authority.biz.entity.UserSystemAuth;
import com.fcbox.authority.client.vo.request.UserSystemAuthVo;

import java.util.List;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/11
 **/
public interface UserSystemAuthService {

    public ModelResult<Void> updateUserSystemAuth(UserSystemAuthVo userSystemAuthVo);

    public ModelResult<UserSystemAuth> selectByUserAccount(String userAccount);
}
