package com.fcbox.authority.biz.mapper;

import com.fcbox.authority.biz.entity.SystemAuthPosition;
import com.fcbox.authority.biz.entity.SystemAuthPositionExample;
import lombok.Data;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SystemAuthPositionMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(SystemAuthPosition record);

    int insertSelective(SystemAuthPosition record);

    List<SystemAuthPosition> selectByExample(SystemAuthPositionExample example);

    SystemAuthPosition selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(SystemAuthPosition record);

    int updateByPrimaryKey(SystemAuthPosition record);
}