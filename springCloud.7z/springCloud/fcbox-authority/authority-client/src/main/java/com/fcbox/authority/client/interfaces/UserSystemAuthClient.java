package com.fcbox.authority.client.interfaces;

import com.fcbox.apimodel.domain.ApiResponseResult;
import com.fcbox.authority.client.vo.request.UserSystemAuthVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/17
 **/
@Api(tags="userAuth")
@FeignClient(name="fcbox-authority")
public interface UserSystemAuthClient {

    @ApiOperation(value = "启用或禁用用户指定系统",notes = "无")
    @ApiImplicitParams(@ApiImplicitParam(name = "userSystemAuthVo",value="传参包装类",required=true))
    @RequestMapping(value="/userAuth/updateUserSystemAuth",method= RequestMethod.POST)
    ApiResponseResult updateUserSystemAuth(@RequestBody() UserSystemAuthVo userSystemAuthVo);


    @ApiOperation(value = "查询用户所有系统的禁用启用信息",notes = "无")
    @ApiImplicitParams(@ApiImplicitParam(name = "userAccount",value="用户账号",required=true))
    @RequestMapping(value="/userAuth/selectUserAllSystemAuth",method= RequestMethod.GET)
    ApiResponseResult selectUserAllSystemAuth(@RequestParam(value = "userAccount") String userAccount);

    @ApiOperation(value = "获取用户是否启用指定系统信息",notes = "无")
    @ApiImplicitParams(@ApiImplicitParam(name = "userSystemAuthVo",value="包装类",required=true))
    @RequestMapping(value="/userAuth/userAuthentication",method= RequestMethod.POST)
    ApiResponseResult userAuthentication(@RequestBody UserSystemAuthVo userSystemAuthVo);
}
