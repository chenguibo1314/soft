package com.fcbox.authority.client.interfaces;

import com.fcbox.apimodel.domain.ApiResponseResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/17
 **/
@Api(tags="accessSystem")
@FeignClient(name="fcbox-authority")
public interface AccessSystemClient{

    @ApiOperation(value = "查询接入SSO的系统列表",notes = "不需要传参")
    @RequestMapping(value="/accessSystem/selectAll",method= RequestMethod.GET)
    ApiResponseResult selectAll();
}
