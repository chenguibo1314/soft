package com.fcbox.authority.client.map;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 删除状态map
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2015-2025
 * createTime: 2019/04/08 19:23
 * modifyTime:
 * modifyBy:
 */
public class DelFlagMap {
    /**
     * 是否删除：是
     */
    public static final int del = 1;
    /**
     * 是否删除：否
     */
    public static final int unDel = 2;

    public static final Map<Integer, String> delFlagMap = new LinkedHashMap<>();

    static {
        delFlagMap.put(del, "是");
        delFlagMap.put(unDel, "否");
    }

    /**
     * 根据key返回描述信息
     *
     * @param key
     * @return
     */
    public static String getDescByKey(int key) {
        return delFlagMap.get(key);
    }

}
