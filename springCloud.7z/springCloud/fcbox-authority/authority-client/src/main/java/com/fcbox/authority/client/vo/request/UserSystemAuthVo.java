package com.fcbox.authority.client.vo.request;

import com.fcbox.apimodel.vo.AbstractVo;
import lombok.Data;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/12
 **/
@Data
public class UserSystemAuthVo extends AbstractVo {
    private String systemCode;

    private String userAccount;

    private String updateEmp;

    private Boolean forbidOrNot;

}
