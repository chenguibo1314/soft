/**
 *
 */
package com.fcbox.appmodel.domain.query;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;

import java.io.Serializable;

/**
 * QueryUserOption发现加上Option<br>
 * 没什么用，反而加长了对象名称，本来QueryUser已足够说明是User的查询对象<br>
 * 就像UserDO一样，User足以表达User对象是领域对象的意义了，不需要加DO。<br>
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/8/22 13:00
 * modifyTime:
 * modifyBy:
 */
public abstract class AbstractQueryEntity implements Serializable {
    private static final Long serialVersionUID = -7511117138255653253L;
    /**
     * 需要附加位（对象加载开关），这里其实就是标记下需不需要在查询的时候把关联的信息显示出来，在manager处进行动态选择结果。
     */
    private Long needAttachBit;
    /**
     * 需要更新加载的对象，需要更新的话，直接对db里面的数据进行更新操作
     */
    private Boolean needUpdateAttach = false;
    /**
     * bit参数
     */
    private Long optionBit;

    public AbstractQueryEntity() {
    }

    public Long getNeedAttachBit() {
        return needAttachBit;
    }

    public void setNeedAttachBit(Long needAttachBit) {
        this.needAttachBit = needAttachBit;
    }

    public Boolean getNeedUpdateAttach() {
        return needUpdateAttach;
    }

    public void setNeedUpdateAttach(Boolean needUpdateAttach) {
        this.needUpdateAttach = needUpdateAttach;
    }

    public Long getOptionBit() {
        return optionBit;
    }

    public void setOptionBit(Long optionBit) {
        this.optionBit = optionBit;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this, SerializerFeature.DisableCircularReferenceDetect);
    }

}
