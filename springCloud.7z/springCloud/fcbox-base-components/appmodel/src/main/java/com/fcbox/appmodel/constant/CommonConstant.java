package com.fcbox.appmodel.constant;

/**
 * @version: v1.0
 * @author: Administrator
 * @Description: project: sysmanager
 * copyright: FCBOX TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/6/6 0006 上午 11:17
 * modifyTime:
 * modifyBy:
 */
public class CommonConstant {
    /**
     * 不存在
     */
    public static final int NO = 0;
    /**
     * 存在
     */
    public static final int YES = 1;

}
