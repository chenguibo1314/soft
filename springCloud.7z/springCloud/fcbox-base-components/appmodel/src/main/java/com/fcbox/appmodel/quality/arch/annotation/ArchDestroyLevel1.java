package com.fcbox.appmodel.quality.arch.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
@Retention(RetentionPolicy.SOURCE)
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.LOCAL_VARIABLE, ElementType.TYPE})
public @interface ArchDestroyLevel1 {
	WhyError[] why();
	String reviewer();
	String[] comment();
	String commentTime();
}
