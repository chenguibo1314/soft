package com.fcbox.appmodel.map.common;

/**
 * 用户id来源
 *
 * @version: v2.0
 * @author: Shuping.Lian
 * project:
 * copyright:
 * createTime: 2018/7/18 10:14
 * modifyTime:
 * modifyBy:
 */
public class UserIdSrcMap {

    /**
     * 小程序用户
     */
    public static final int CLIENT = 1;

    /**
     * 商家后台用户
     */
    public static final int MCH_BACKEND = 2;

    /**
     * 运营后台用户
     */
    public static final int BUS_BACKEND = 3;

    /**
     * 商城用户(puff、wap)
     */
    public static final int MALL = 4;

}
