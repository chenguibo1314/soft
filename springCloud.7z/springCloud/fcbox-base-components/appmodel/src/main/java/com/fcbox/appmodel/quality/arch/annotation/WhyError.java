package com.fcbox.appmodel.quality.arch.annotation;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public enum WhyError {
    /**
     * 事务代码不正确，混和了事务，一些操作不需要混和在真正所需要的事务中
     */
    transactionMix_level1,

    /**
     * 对某组件的用法不符合其设计
     */
    errorToComponentDesign_level2;
}
