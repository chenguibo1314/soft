package com.fcbox.appmodel.map.common;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 客户端id：h5前端-1，微信前端-2，android前端-3，ios前端-4,admin前端-5，web前端-6，烘焙-7，好酷-8
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright:
 * createTime: 2018/11/22 18:30
 * modifyTime:
 * modifyBy:
 */
public class AppClientMap {
    /**
     * 网易七鱼
     */
    public static final String qiyu = "XF0001";
    /**
     * 商城微信公众号
     */
    public static final String wxMp = "XF0002";
    /**
     * h5商城
     */
    public static final String h5 = "XF0003";
    /**
     * 运营后台
     */
    public static final String backEnd = "XF0004";
    /**
     * pc商城
     */
    public static final String pc = "XF0005";
    /**
     * 天润
     */
    public static final String tianYun = "XF0006";
    /**
     * 三方扒单
     */
    public static final String climborder = "XF0007";
    /**
     * 配送app-ios
     */
    public static final String deliveryAppIos = "XF0008";
    /**
     * 配送app-android
     */
    public static final String deliveryAppAndroid = "XF0009";
    /**
     * 好酷
     */
    public static final String haoKu = "XF0010";


    /**
     * 发票扫码
     */
    public static final String qrApplyInvoice = "XF0011";

    /**
     * 幸福微商城小程序
     */
    public static final String giftAPP = "XF0012";

    public static final Map<String, String> appClientMap = new LinkedHashMap<>();

    static {
        appClientMap.put(qiyu, "网易七鱼");
        appClientMap.put(wxMp, "商城微信公众号");
        appClientMap.put(h5, "h5商城");
        appClientMap.put(backEnd, "运营后台");
        appClientMap.put(pc, "pc商城");
        appClientMap.put(tianYun, "天润");
        appClientMap.put(climborder, "三方扒单");
        appClientMap.put(deliveryAppIos, "配送app-ios");
        appClientMap.put(deliveryAppAndroid, "配送app-android");      
        appClientMap.put(haoKu,"好酷");
        appClientMap.put(qrApplyInvoice, "发票扫码页面");
        appClientMap.put(giftAPP,"幸福微商城小程序");
    }

    /**
     * 根据key返回描述信息
     *
     * @param key
     * @return
     */
    public static String getDescByKey(String key) {
        return appClientMap.get(key);
    }

}
