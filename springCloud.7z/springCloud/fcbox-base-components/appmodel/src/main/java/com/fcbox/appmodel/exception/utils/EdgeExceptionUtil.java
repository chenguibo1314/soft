package com.fcbox.appmodel.exception.utils;

/**
 * 边界异常工具类
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public abstract class EdgeExceptionUtil {

    /**
     * @param cause
     * @return
     * @version v1.0
     * @author Ningbo.Chen
     * @createTime: 2013-5-20 上午11:03:27
     * @modifyTime:
     */
    public static RuntimeException newRuntimeExceptionWithoutCause(Exception cause) {
        RuntimeException exceptResult = new RuntimeException(cause.getLocalizedMessage());
        exceptResult.setStackTrace(cause.getStackTrace());
        return exceptResult;
    }

    /**
     * @param newException
     * @param cause
     * @return
     * @version v1.0
     * @author Ningbo.Chen
     * @createTime: 2013-5-20 上午11:03:30
     * @modifyTime:
     */
    public static Exception exceptionWithStackTraceFromCause(Exception newException, Exception cause) {
        newException.setStackTrace(cause.getStackTrace());
        return newException;
    }
}
