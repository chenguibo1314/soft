/**
 *
 */
package com.fcbox.appmodel.domain.result;

/**
 * 幂等+redo+消息模式
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class IdempotentCheckResult extends BaseResult {
    private static final long serialVersionUID = 883170549217078258L;

}
