package com.fcbox.appmodel.constant;

/**
 * 统一管理打印日志的前缀名称
 * @author WILLIAM.ZUO
 */
public class LogInfoConstant {

    public static final String INPUT="[入参]";

    public static final String OUTPUT="[出参]";


}
