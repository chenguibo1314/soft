package com.fcbox.appmodel.domain.result;

import com.fcbox.appmodel.page.PagingList;

/**
 * 专门针对分页结果进行封装
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
@SuppressWarnings("rawtypes")
public class PageResult<T> extends BaseResult {

    private static final long serialVersionUID = 1400532352709932863L;

    private PagingList<T> page;

    public PagingList<T> getPage() {
        return page;
    }

    public void setPage(PagingList<T> page) {
        this.page = page;
    }

    public <SubClass extends PageResult> SubClass withPage(PagingList<T> page) {
        this.page = page;
        return (SubClass) this;
    }

}
