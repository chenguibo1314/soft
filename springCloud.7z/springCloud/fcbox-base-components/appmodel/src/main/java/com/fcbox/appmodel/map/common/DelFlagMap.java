package com.fcbox.appmodel.map.common;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/3/4 13:18
 * modifyTime:
 * modifyBy:
 */
public class DelFlagMap {
    /**
     * 删除0
     */
    public static final int del = 0;
    /**
     * 启用1
     */
    public static final int unDel = 1;

    public static final Map<Integer, String> delFlagMap = new LinkedHashMap<>();

    static {
        delFlagMap.put(del, "删除");
        delFlagMap.put(unDel, "启用");
    }

    /**
     * 根据key返回描述信息
     *
     * @param key
     * @return
     */
    public static String getDescByKey(int key) {
        return delFlagMap.get(key);
    }
}
