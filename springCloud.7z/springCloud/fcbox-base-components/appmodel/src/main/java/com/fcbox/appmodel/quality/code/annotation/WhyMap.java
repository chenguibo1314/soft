package com.fcbox.appmodel.quality.code.annotation;

/**
 * @version: v1.0
 * @author: Haixiang.Dai
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class WhyMap {
}
