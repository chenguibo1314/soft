package com.fcbox.appmodel.map.common;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 客户端id：h5前端-1，微信前端-2，android前端-3，ios前端-4,admin前端-5，web前端-6，烘焙-7，好酷-8
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright:
 * createTime: 2018/11/22 18:30
 * modifyTime:
 * modifyBy:
 */
@Deprecated
public class CommonClientMap {
    /**
     * 默认为0
     */
    public static final int client_default = 0;
    /**
     * h5
     */
    public static final int front_h5 = 1;
    /**
     * weixin
     */
    public static final int front_weixin = 2;
    /**
     * android
     */
    public static final int front_android = 3;
    /**
     * ios
     */
    public static final int front_ios = 4;
    /**
     * backend
     */
    public static final int backEnd = 5;
    /**
     * front
     */
    public static final int front_web = 6;
    /**
     * baking
     */
    public static final int baking = 7;
    /**
     * cool
     */
    public static final int cool = 8;
    /**
     * tmall
     */
    public static final int tmall = 9;
    /**
     * eleme
     */
    public static final int eleme = 10;
    /**
     * jd
     */
    public static final int jd = 11;
    /**
     * meituan
     */
    public static final int meituan = 12;
    /**
     * baidu_takeaway
     */
    public static final int baidu_takeaway = 13;

    /**
     * tianrun
     */
    public static final int tianrun = 14;

    public static final Map<Integer, String> clientMap = new LinkedHashMap<Integer, String>();

    static {
        clientMap.put(client_default, "默认为0");
        clientMap.put(front_h5, "h5");
        clientMap.put(front_weixin, "weixin");
        clientMap.put(front_android, "android");
        clientMap.put(front_ios, "ios");
        clientMap.put(backEnd, "backend");
        clientMap.put(front_web, "front");
        clientMap.put(baking, "baking");
        clientMap.put(cool, "cool");
        clientMap.put(tmall, "tmall");
        clientMap.put(eleme, "eleme");
        clientMap.put(jd, "jd");
        clientMap.put(meituan, "meituan");
        clientMap.put(tianrun, "tianrun");
    }

    /**
     * 根据key返回描述信息
     *
     * @param key
     * @return
     */
    public static String getDescByKey(int key) {
        return clientMap.get(key);
    }

}
