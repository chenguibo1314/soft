package com.fcbox.appmodel.domain;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.Version;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 抽象的领域基类
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright:
 * createTime: 2018/11/21 10:24
 * modifyTime:
 * modifyBy:
 */
public abstract class AbstractDo implements Serializable {
    private static final long serialVersionUID = -6948912771711907699L;
    /**
     * 实体唯一的标识符，用基本类型
     */
    @TableId
    private Long id = 0L;
    /**
     * 实体或者对象的版本号，乐观锁，用基本类型<br>
     * 此处要注意，版本号的更新问题。
     */
    @Version
    private Long version = 0L;
    /**
     * 创建人
     */
    private Long createdBy = 0L;
    /**
     * 创建时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdTime;
    /**
     * 记录更新操作者
     */
    private Long updatedBy = 0L;
    /**
     * 记录更新时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updatedTime;
    /**
     * 软删除标志 删除为0 启用为1 逻辑删除，物理上不删除
     */
    @TableLogic
    @TableField(exist = false)
    private Long delFlag = 1L;

    public AbstractDo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(LocalDateTime createdTime) {
        this.createdTime = createdTime;
    }

    public Long getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Long updatedBy) {
        this.updatedBy = updatedBy;
    }

    public LocalDateTime getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(LocalDateTime updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Long getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Long delFlag) {
        this.delFlag = delFlag;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this, SerializerFeature.DisableCircularReferenceDetect);
    }

}
