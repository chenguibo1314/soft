/**
 *
 */
package com.fcbox.appmodel.domain.option;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public interface ClientAppInfo {

    String getClientAppIp();

    String getClientAppName();

}
