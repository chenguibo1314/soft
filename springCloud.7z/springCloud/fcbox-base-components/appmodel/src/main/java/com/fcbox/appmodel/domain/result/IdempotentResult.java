/**
 *
 */
package com.fcbox.appmodel.domain.result;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
@SuppressWarnings("rawtypes")
public class IdempotentResult<T> extends ModelResult<T> {
    private static final long serialVersionUID = 1542493460563645012L;

}
