/**
 *
 */
package com.fcbox.appmodel.domain.option;

/**
 * 实现幂等：MemberWalletLog里用 transType + logId做幂等不够清晰/不太好。
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public interface IdempotentWriteOption {

    void setIdempotentIdSource(String idFromThisTable);

    void setIdempotentId(String id);

    void setIdempotentIdSource(Integer idFromThisTable);

    void setIdempotentId(Long id);

}
