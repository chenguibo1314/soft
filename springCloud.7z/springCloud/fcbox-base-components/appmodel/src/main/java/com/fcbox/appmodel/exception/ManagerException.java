package com.fcbox.appmodel.exception;

/**
 * 内部业务处理时的异常抽象
 *
 * @version: v1.0
 * @author: Haixiang.Dai
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class ManagerException extends Exception {

    private static final long serialVersionUID = -2934068971010820261L;

    public ManagerException() {
        super();
    }

    public ManagerException(String msg) {
        super(msg);
    }

    public ManagerException(String msg, Throwable cause) {
        super(msg, cause);
    }

    public ManagerException(Throwable cause) {
        super(cause);
    }

}
