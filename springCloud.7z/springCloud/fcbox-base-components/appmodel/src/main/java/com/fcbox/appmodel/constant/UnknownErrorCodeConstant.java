package com.fcbox.appmodel.constant;

import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 *  错误码定义规范：（不同的项目自行扩展自此抽象map）
 * <p>
 * 8位数的返回码，00000000，前3位为项目编码，第4+5位为模块编码，后3位为该项目的业务编码。
 * <p>
 * 001开头的为商品业务返回码
 * 002开头的为基础服务业务返回码
 * 003开头的为业务返回码...
 * 004开头的为业务返回码...
 * 005开头的为业务返回码...
 * 006开头的为业务返回码...
 * 007开头的为业务返回码...
 * 008开头的为业务返回码...
 * 009开头的为业务返回码...
 * 010开头的为业务返回码...
 *
 * @version: v1.0
 * @author: Haixiang.Dai
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public abstract class UnknownErrorCodeConstant {
    public final static String exceptionUnknownError = "exceptionUnknownError";
    public final static String exceptionCanRetry = "exceptionCanRetry";
    public final static String exceptionRetryAfterBizCheck = "exceptionRetryAfterBizCheck";
    public final static String exceptionNeedTechCheck = "exceptionNeedTechCheck";

    /**
     * ConcurrentHashMap此处使用多线程的HashMap
     */
    public final static Map<String, String> errorMap = new ConcurrentHashMap<String, String>();

    static {
        errorMap.put(exceptionUnknownError, "遇到意料之外错误");
        errorMap.put(exceptionCanRetry, "遇到意料之外错误，如未达到操作要求，可再重试");
        errorMap.put(exceptionRetryAfterBizCheck, "遇到意料之外错误，请检查一下业务数据，没大问题可再重试");
        errorMap.put(exceptionNeedTechCheck, "遇到错误，请打开详细消息复制/截屏后告知客服检查");// 客服意思即是客服和开发人员
    }

    /**
     * @param errorCode
     * @param msg
     */
    public static void putMsg(String errorCode, String msg) {
        errorMap.put(errorCode, msg);
    }

    /**
     * @param errorCode
     * @return
     */
    public static String getMsg(String errorCode) {
        if (StringUtils.isBlank(errorCode)) {
            return errorMap.get(exceptionUnknownError);
        }
        return errorMap.get(errorCode);
    }

}
