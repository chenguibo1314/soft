/**
 *
 */
package com.fcbox.appmodel.exception.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 插入异常日志打印与抛出异常到下一级
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public abstract class InsertExceptionLogUtil {

    private final static Logger LOGGER = LoggerFactory.getLogger(InsertExceptionLogUtil.class);

    public static void showInsertExceptionLog(int affectedCount) {
        if (affectedCount != 1) {
            String msg = "{msg:'插入记录有问题',affectedCount:" + affectedCount + ",errorSource:'sql'}";
            LOGGER.error(msg);
            throw new RuntimeException(msg);
        }
    }
}
