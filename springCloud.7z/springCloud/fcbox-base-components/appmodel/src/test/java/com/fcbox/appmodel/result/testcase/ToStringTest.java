package com.fcbox.appmodel.result.testcase;

import com.fcbox.appmodel.domain.result.BaseResult;
import org.apache.commons.beanutils.BeanUtils;
import org.junit.Assert;
import org.junit.Test;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: ssxingshou-base-component
 * copyright: SSXINGSHOU TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/6/29 21:24
 * modifyTime:
 * modifyBy:
 */
public class ToStringTest {

    @Test
    public void test_BaseResult() throws Throwable {
        BaseResult result = new BaseResult();
        result.withError(null, null);
        Assert.assertNotNull("BaseResult.toString()", result.toString());

        BaseResult result2 = new BaseResult();
        BeanUtils.cloneBean(result);
        BeanUtils.copyProperties(result2, result);
    }
}
