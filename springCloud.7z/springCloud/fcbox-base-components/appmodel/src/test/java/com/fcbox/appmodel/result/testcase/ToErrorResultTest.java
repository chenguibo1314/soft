package com.fcbox.appmodel.result.testcase;

import com.fcbox.appmodel.constant.UnknownErrorCodeConstant;
import com.fcbox.appmodel.result.support.NeedResult;
import com.fcbox.appmodel.result.support.UnsuccessResult;
import com.fcbox.appmodel.domain.result.BaseResult;
import org.junit.Assert;
import org.junit.Test;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class ToErrorResultTest<T> {

	@Test
	public void test() {
		NeedResult<T> result = returnNeedResult();
		if (result.isSuccess()) {
			Assert.assertFalse("success", result.isSuccess());
		}
	}

	private NeedResult<T> returnNeedResult() {
		return returnUnsuccessResult().toErrorResult(new NeedResult<T>());
	}

	private BaseResult returnUnsuccessResult() {
		BaseResult result = new UnsuccessResult();
		return result.withError(UnknownErrorCodeConstant.exceptionCanRetry);
	}
}
