package com.fcbox.appmodel;

import com.fcbox.appmodel.quality.arch.annotation.ArchDestroyLevel1;
import com.fcbox.appmodel.quality.arch.annotation.WhyError;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: ssxingshou-base-component
 * copyright: SSXINGSHOU TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/6/29 21:24
 * modifyTime:
 * modifyBy:
 */
public class AppTest {
	private final Logger LOGGER = LoggerFactory.getLogger(getClass());

	@Test
	public void test() {
		LOGGER.info(String.format("{msg:'abnormalCause can`t be null', prevOrderId:%1$d}", 1234));
	}

	/**
	 * 质量管理
	 */
	private void exampleForArchDestroyLevel() {
		@ArchDestroyLevel1(why = WhyError.transactionMix_level1, reviewer = "cnhans", comment = "comment", commentTime = "2014-12-24")
		int transactionMix;

		@ArchDestroyLevel1(why = WhyError.transactionMix_level1, reviewer = "cnhans", comment = { "comment1", "comment2" }, commentTime = "2014-12-24")
		int transactionMix2;

		Runnable a = new Runnable() {
			@Override
			@ArchDestroyLevel1(why = WhyError.transactionMix_level1, comment = { "本意是想把payStatus的update和钱包流水作事务，这里将几个sql操作混在一起了", "orderStatus 可先update",
					"payStatus和insert钱包流水按目前事务意愿可作事务，但这个事务比较假，因为order表和plan表是不同的数据库，是要分布式事务才正确，或做好redo", "payStatus和钱包流水事务需要用redo分离", "需要payStatus增加'扣款中'，并增加可以让财务人员redo修复或定时补偿的接口" }, reviewer = "cnhans", commentTime = "2014-12-24")
			public void run() {
				// TODO Auto-generated method stub

			}
		};
	}
}
