package com.fcbox.appmodel.result.support;

import com.fcbox.appmodel.domain.result.BaseResult;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class UnsuccessResult extends BaseResult {
	private static final long serialVersionUID = -3176216403105662497L;

}
