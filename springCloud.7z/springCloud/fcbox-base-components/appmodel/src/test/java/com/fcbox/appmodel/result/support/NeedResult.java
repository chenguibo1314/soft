package com.fcbox.appmodel.result.support;

import com.fcbox.appmodel.domain.result.ModelResult;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: ssxingshou-base-component
 * copyright: SSXINGSHOU TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/6/29 21:23
 * modifyTime:
 * modifyBy:
 */
public class NeedResult<T> extends ModelResult<T> {
    private static final long serialVersionUID = -6132493005072346294L;

    private long field1;

    public long getField1() {
        return field1;
    }

    public void setField1(long field1) {
        this.field1 = field1;
    }

}
