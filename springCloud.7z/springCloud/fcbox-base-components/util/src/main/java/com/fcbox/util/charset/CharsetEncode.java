/**
 *
 */
package com.fcbox.util.charset;

/**
 * 全局的字符编码uft-8
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime: 2018/5/29 8:22
 * modifyTime:
 * modifyBy:
 */
public class CharsetEncode {

    /**
     * utf-8编码
     */
    public static final String encode_utf8 = "utf-8";

}
