/**
 *
 */
package com.fcbox.util.security;

import org.apache.commons.codec.binary.Base64;

/**
 * 使用Base64加密解密
 *
 * @version: v1.0
 * @author: Haixiang.Dai
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public final class Base64Util {

    /**
     * 使用Base64加密
     *
     * @param plainText
     * @return
     */
    public static String encodeStr(String plainText) {
        byte[] b = plainText.getBytes();
        Base64 base64 = new Base64();
        b = base64.encode(b);
        String s = new String(b);
        return s;
    }

    /**
     * 使用Base64解密
     *
     * @param encodeStr
     * @return
     */
    public static String decodeStr(String encodeStr) {
        byte[] b = encodeStr.getBytes();
        Base64 base64 = new Base64();
        b = base64.decode(b);
        String s = new String(b);
        return s;
    }

}
