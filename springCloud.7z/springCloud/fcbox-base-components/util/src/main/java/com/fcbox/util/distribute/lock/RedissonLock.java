//package com.fcbox.util.distribute.lock;

//import lombok.extern.slf4j.Slf4j;
//import org.redisson.api.RLock;
//import org.redisson.api.RedissonClient;
//
//import java.util.concurrent.TimeUnit;

//redisson 与spring data redis整合后，redisTemplate.opsForValue().setIfAbsent(K key,
//                              V value,
//                              long timeout,
//                              TimeUnit unit)
//会返回空值（并未开启事务，未pipeline），造成RedisLock的实现问题。
//担心 redisson 实现不稳定，暂时不使用


///**
// * ClassName: RedissonLock
// *
// * @Description: redis锁
// * @author Ningbo.Chen
// * @date 2019/4/30
// *
// */
//@Slf4j
//public class RedissonLock {
//    private static final String lockKeyPrefix = "redisLock_";
//    /**
//     *
//     * @param redisson 客户端
//     * @param lockKey 加锁key
//     * @param leaseTime 锁过期时间,单位：秒
//     * @return
//     */
//    public static boolean acquire(RedissonClient redisson,String lockKey,long leaseTime){
//        boolean result = false;
//        String key = lockKeyPrefix.concat(lockKey);
//        RLock mylock = redisson.getLock(key);
//        try {
//            result = mylock.tryLock(leaseTime,TimeUnit.SECONDS);
//        } catch (InterruptedException e) {
//            log.error("acquire lock error,key:{},exception:{}",key,e.getMessage());
//        }
//        return result;
//    }
//
//    /**
//     *
//     * @param redisson 客户端
//     * @param lockKey 加锁key
//     * @param waitTime 尝试获取锁时间,该段时间内会不断尝试获取锁,单位：秒
//     * @param leaseTime 锁过期时间,单位：秒
//     * @return
//     */
//    public static boolean acquire(RedissonClient redisson,String lockKey,long waitTime,long leaseTime){
//        boolean result = false;
//        String key = lockKeyPrefix.concat(lockKey);
//        RLock mylock = redisson.getLock(key);
//        try {
//            result = mylock.tryLock(waitTime,leaseTime,TimeUnit.SECONDS);
//        } catch (InterruptedException e) {
//            log.error("acquire lock error,key:{},exception:{}",key,e.getMessage());
//        }
//        return result;
//    }
//
//    /**
//     *
//     * @param redisson 客户端
//     * @param lockKey 加锁key
//     */
//    public void release(RedissonClient redisson,String lockKey){
//        String key = lockKeyPrefix.concat(lockKey);
//        RLock mylock = redisson.getLock(key);
//        mylock.unlock();
//    }
//
//}
