package com.fcbox.util.common;

/**
 * @version: v1.0
 * @author: Administrator
 * @Description:
 * copyright: FCBOX TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/1/2 0002 下午 3:05
 * modifyTime:
 * modifyBy:
 */
public class NumberUtil {
    public static boolean effectId(Integer id) {
        if (id != null && id > 0) {
            return true;
        }
        return false;
    }
}
