package com.fcbox.util.datetime;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.time.FastDateFormat;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class DateUtil {

    public final static long   ONE_DAY_SECONDS        = 86400;
    public static final int SECOND = 1;
    public static final int MINUTE = 2;
    public static final int HOUR = 3;
    public static final int DAY = 4;
    public static final int MILLI_FACTOR = 1000;
    public static final FastDateFormat ISO_DATETIME_FORMAT = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");

    /*
     * private static DateFormat dateFormat = null; private static DateFormat
     * longDateFormat = null; private static DateFormat dateWebFormat = null;
     */
    public final static String shortFormat            = "yyyyMMdd";
    public final static String longFormat             = "yyyyMMddHHmmss";
    public final static String webFormat              = "yyyy-MM-dd";
    public final static String timeFormat             = "HHmmss";
    public final static String TIME_MILLES_FORMAT            = "HHmmssSSS";
    public final static String HOUR_MINUTE_Format     = "HH:mm";
    public final static String WEEK_FORMAT = "EEEE";
    public final static String MONTH_DAY_Format       = "MM-dd";
    public final static String monthFormat            = "yyyyMM";
    public final static String chineseDtFormat        = "yyyy年MM月dd日";
    public final static String newFormat              = "yyyy-MM-dd HH:mm:ss";
    public final static String biasFormat              = "yyyy/MM/dd HH:mm:ss";
    public final static String noSecondFormat         = "yyyy-MM-dd HH:mm";
    public final static String PROCES_FORMAT          = "yyyyMMddHHmmss.SSS";
    public final static String NEW_PROCES_FORMAT          = "yyyy-MM-dd HH:mm:ss.SSS";
    public final static String GMT_FORMAT             = "EEE, dd MMM yyyy HH:mm:ss z";
    public final static String GMT                    = "GMT";
    public final static long   ONE_DAY_MILL_SECONDS   = 86400000;
    public final static Long   ONE_HOUR_MILL_TIMES    = 60 * 60 * 1000l;

    public final static Long   TIMEMILLS              = 1000l;

    public final static Long   ONE_DAY_MILL_TIMES     = 24 * ONE_HOUR_MILL_TIMES;

    public final static Long   TWELVE_HOUR_MILL_TIMES = 12 * ONE_HOUR_MILL_TIMES;

    public static DateFormat getNewDateFormat(String pattern) {
        DateFormat df = new SimpleDateFormat(pattern);

        df.setLenient(false);
        return df;
    }

    public static String format(Date date, String format) {
        if (date == null) {
            return null;
        }

        return new SimpleDateFormat(format).format(date);
    }

    public static Date parseDateNoTime(String sDate) throws ParseException {
        DateFormat dateFormat = new SimpleDateFormat(shortFormat);

        if ((sDate == null) || (sDate.length() < shortFormat.length())) {
            throw new ParseException("length too little", 0);
        }

        if (!StringUtils.isNumeric(sDate)) {
            throw new ParseException("not all digit", 0);
        }

        return dateFormat.parse(sDate);
    }

    public static Date parseDateNoTime(String sDate, String format) throws ParseException {
        if (StringUtils.isBlank(format)) {
            throw new ParseException("Null format. ", 0);
        }

        DateFormat dateFormat = new SimpleDateFormat(format);

        if ((sDate == null) || (sDate.length() < format.length())) {
            throw new ParseException("length too little", 0);
        }

        return dateFormat.parse(sDate);
    }

    public static Date parseDateNoTimeWithDelimit(String sDate, String delimit)
                                                                               throws ParseException {
        sDate = sDate.replaceAll(delimit, "");

        DateFormat dateFormat = new SimpleDateFormat(shortFormat);

        if ((sDate == null) || (sDate.length() != shortFormat.length())) {
            throw new ParseException("length not match", 0);
        }

        return dateFormat.parse(sDate);
    }

    public static Date parseDateLongFormat(String sDate) {
        DateFormat dateFormat = new SimpleDateFormat(longFormat);
        Date d = null;

        if ((sDate != null) && (sDate.length() == longFormat.length())) {
            try {
                d = dateFormat.parse(sDate);
            } catch (ParseException ex) {
                return null;
            }
        }

        return d;
    }

    public static Date parseDateNewFormat(String sDate) {
        DateFormat dateFormat = new SimpleDateFormat(newFormat);
        Date d = null;
        if ((sDate != null) && (sDate.length() == newFormat.length())) {
            try {
                d = dateFormat.parse(sDate);
            } catch (ParseException ex) {
                return null;
            }
        }
        return d;
    }

    /**
     * 计算当前时间几小时之后的时间
     *
     * @param date
     * @param hours
     *
     * @return
     */
    public static Date addHours(Date date, long hours) {
        return addMinutes(date, hours * 60);
    }

    /**
     * 计算当前时间几分钟之后的时间
     *
     * @param date
     * @param minutes
     *
     * @return
     */
    public static Date addMinutes(Date date, long minutes) {
        return addSeconds(date, minutes * 60);
    }

    /**
     * @param date1
     * @param secs
     *
     * @return
     */

    public static Date addSeconds(Date date1, long secs) {
        return new Date(date1.getTime() + (secs * 1000));
    }

    /**
     * 判断输入的字符串是否为合法的小时
     *
     * @param hourStr
     *
     * @return true/false
     */
    public static boolean isValidHour(String hourStr) {
        if (!StringUtils.isEmpty(hourStr) && StringUtils.isNumeric(hourStr)) {
            int hour = new Integer(hourStr).intValue();

            if ((hour >= 0) && (hour <= 23)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 判断输入的字符串是否为合法的分或秒
     *
     * @param str
     *
     * @return true/false
     */
    public static boolean isValidMinuteOrSecond(String str) {
        if (!StringUtils.isEmpty(str) && StringUtils.isNumeric(str)) {
            int hour = new Integer(str).intValue();

            if ((hour >= 0) && (hour <= 59)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 取得新的日期
     *
     * @param date1 日期
     * @param days 天数
     *
     * @return 新的日期
     */
    public static Date addDays(Date date1, long days) {
        return addSeconds(date1, days * ONE_DAY_SECONDS);
    }

    public static String getTomorrowDateString(String sDate) throws ParseException {
        Date aDate = parseDateNoTime(sDate);

        aDate = addSeconds(aDate, ONE_DAY_SECONDS);

        return getDateString(aDate);
    }

    public static String getLongDateString(Date date) {
        DateFormat dateFormat = new SimpleDateFormat(longFormat);

        return getDateString(date, dateFormat);
    }

    public static String getNewFormatDateString(Date date) {
        DateFormat dateFormat = new SimpleDateFormat(newFormat);
        return getDateString(date, dateFormat);
    }

    public static String getDateString(Date date, DateFormat dateFormat) {
        if (date == null || dateFormat == null) {
            return null;
        }

        return dateFormat.format(date);
    }

    public static String getYesterDayDateString(String sDate) throws ParseException {
        Date aDate = parseDateNoTime(sDate);

        aDate = addSeconds(aDate, -ONE_DAY_SECONDS);

        return getDateString(aDate);
    }

    /**
     * @return 当天的时间格式化为"yyyyMMdd"
     */
    public static String getDateString(Date date) {
        DateFormat df = getNewDateFormat(shortFormat);

        return df.format(date);
    }

    public static String getWebDateString(Date date) {
        DateFormat dateFormat = getNewDateFormat(webFormat);

        return getDateString(date, dateFormat);
    }

    /**
     * 取得“X年X月X日”的日期格式
     *
     * @param date
     *
     * @return
     */
    public static String getChineseDateString(Date date) {
        DateFormat dateFormat = getNewDateFormat(chineseDtFormat);

        return getDateString(date, dateFormat);
    }

    public static Date convertChineseString2Date(String date) {
        DateFormat dateFormat = getNewDateFormat(chineseDtFormat);
        //date = date.replace("年", "-").replace("月", "-").replace("日", "");
        try {
            return dateFormat.parse(date);
        } catch (ParseException e) {
        }

        return null;
    }

    public static String getTodayString() {
        DateFormat dateFormat = getNewDateFormat(shortFormat);

        return getDateString(new Date(), dateFormat);
    }

    public static String getTimeString(Date date) {
        DateFormat dateFormat = getNewDateFormat(timeFormat);

        return getDateString(date, dateFormat);
    }

    public static String getBeforeDayString(int days) {
        Date date = new Date(System.currentTimeMillis() - (ONE_DAY_MILL_SECONDS * days));
        DateFormat dateFormat = getNewDateFormat(shortFormat);

        return getDateString(date, dateFormat);
    }

    /**
     * 取得两个日期间隔秒数（日期1-日期2）
     *
     * @param one 日期1
     * @param two 日期2
     *
     * @return 间隔秒数
     */
    public static long getDiffSeconds(Date one, Date two) {
        Calendar sysDate = new GregorianCalendar();

        sysDate.setTime(one);

        Calendar failDate = new GregorianCalendar();

        failDate.setTime(two);
        return (sysDate.getTimeInMillis() - failDate.getTimeInMillis()) / 1000;
    }

    public static long getDiffMinutes(Date one, Date two) {
        Calendar sysDate = new GregorianCalendar();

        sysDate.setTime(one);

        Calendar failDate = new GregorianCalendar();

        failDate.setTime(two);
        return (sysDate.getTimeInMillis() - failDate.getTimeInMillis()) / (60 * 1000);
    }

    /**
     * 取得两个日期的间隔天数
     *
     * @param one
     * @param two
     *
     * @return 间隔天数
     */
    public static long getDiffDays(Date one, Date two) {
        Calendar sysDate = new GregorianCalendar();

        sysDate.setTime(one);

        Calendar failDate = new GregorianCalendar();

        failDate.setTime(two);
        return (sysDate.getTimeInMillis() - failDate.getTimeInMillis()) / (24 * 60 * 60 * 1000);
    }

    public static String getBeforeDayString(String dateString, int days) {
        Date date;
        DateFormat df = getNewDateFormat(shortFormat);

        try {
            date = df.parse(dateString);
        } catch (ParseException e) {
            date = new Date();
        }

        date = new Date(date.getTime() - (ONE_DAY_MILL_SECONDS * days));

        return df.format(date);
    }
    
    /**
     * 按照给定格式返回代表日期的字符串
     *
     * @param pDate  Date
     * @param format String 日期格式
     *
     * @return String 代表日期的字符串
     */
    public static String formatDate(Date pDate, String format) {

        if (pDate == null) {
            pDate = new Date();
        }
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(pDate);
    }
    
    /**
     * 把字符串转化为日期<br>
     *
     */
    public static Date parseDate(String date, String pattern) {
        try {
            return DateUtils.parseDate(date, new String[] {pattern});
        } catch (ParseException e) {
            return null;
        }
    }
    
    /**
     * 把字符串转化为日期<br>
     * 使用yyyy-MM-dd作为样式
     *
     */
    public static Date parseDate(String date) {
        if (date == null) {
            return null;
        }
        try {
            return DateUtils.parseDate(date, new String[] {longFormat});
        } catch (ParseException e) {
            return null;
        }
    }

    public static boolean isValidShortDateFormat(String strDate) {
        if (strDate.length() != shortFormat.length()) {
            return false;
        }

        try {
            Integer.parseInt(strDate); //---- 避免日期中输入非数字 ----
        } catch (Exception NumberFormatException) {
            return false;
        }

        DateFormat df = getNewDateFormat(shortFormat);

        try {
            df.parse(strDate);
        } catch (ParseException e) {
            return false;
        }

        return true;
    }

    public static boolean isValidShortDateFormat(String strDate, String delimiter) {
        String temp = strDate.replaceAll(delimiter, "");

        return isValidShortDateFormat(temp);
    }

    /**
     * 判断表示时间的字符是否为符合yyyyMMddHHmmss格式
     * 
     * @param strDate
     * @return
     */
    public static boolean isValidLongDateFormat(String strDate) {
        if (strDate.length() != longFormat.length()) {
            return false;
        }

        try {
            Long.parseLong(strDate); //---- 避免日期中输入非数字 ----
        } catch (Exception NumberFormatException) {
            return false;
        }

        DateFormat df = getNewDateFormat(longFormat);

        try {
            df.parse(strDate);
        } catch (ParseException e) {
            return false;
        }

        return true;
    }

    /**
     * 判断表示时间的字符是否为符合yyyyMMddHHmmss格式
     * 
     * @param strDate
     * @param delimiter
     * @return
     */
    public static boolean isValidLongDateFormat(String strDate, String delimiter) {
        String temp = strDate.replaceAll(delimiter, "");

        return isValidLongDateFormat(temp);
    }

    public static String getShortDateString(String strDate) {
        return getShortDateString(strDate, "-|/");
    }

    public static String getShortDateString(String strDate, String delimiter) {
        if (StringUtils.isBlank(strDate)) {
            return null;
        }

        String temp = strDate.replaceAll(delimiter, "");

        if (isValidShortDateFormat(temp)) {
            return temp;
        }

        return null;
    }

    public static String getShortFirstDayOfMonth() {
        Calendar cal = Calendar.getInstance();
        Date dt = new Date();

        cal.setTime(dt);
        cal.set(Calendar.DAY_OF_MONTH, 1);

        DateFormat df = getNewDateFormat(shortFormat);

        return df.format(cal.getTime());
    }

    public static Date getShortFirstDayOfCurMonth() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_MONTH, 1);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.clear(Calendar.MINUTE);
        c.clear(Calendar.SECOND);
        return c.getTime();
    }

    public static Date getShortLastDayOfCurMonth() {
        Calendar ca = Calendar.getInstance();
        ca.set(Calendar.DAY_OF_MONTH, ca.getActualMaximum(Calendar.DAY_OF_MONTH));
        ca.set(Calendar.HOUR_OF_DAY, 23);
        ca.set(Calendar.MINUTE, 59);
        ca.set(Calendar.SECOND, 59);
        return ca.getTime();
    }

    public static String getWebTodayString() {
        DateFormat df = getNewDateFormat(webFormat);

        return df.format(new Date());
    }

    public static String getWebFirstDayOfMonth() {
        Calendar cal = Calendar.getInstance();
        Date dt = new Date();

        cal.setTime(dt);
        cal.set(Calendar.DAY_OF_MONTH, 1);

        DateFormat df = getNewDateFormat(webFormat);

        return df.format(cal.getTime());
    }

    public static String convert(String dateString, DateFormat formatIn, DateFormat formatOut) {
        try {
            Date date = formatIn.parse(dateString);

            return formatOut.format(date);
        } catch (ParseException e) {
            return "";
        }
    }

    public static String convert2WebFormat(String dateString) {
        DateFormat df1 = getNewDateFormat(shortFormat);
        DateFormat df2 = getNewDateFormat(webFormat);

        return convert(dateString, df1, df2);
    }

    public static String convert2ChineseDtFormat(String dateString) {
        DateFormat df1 = getNewDateFormat(shortFormat);
        DateFormat df2 = getNewDateFormat(chineseDtFormat);

        return convert(dateString, df1, df2);
    }

    public static String convertFromWebFormat(String dateString) {
        DateFormat df1 = getNewDateFormat(shortFormat);
        DateFormat df2 = getNewDateFormat(webFormat);

        return convert(dateString, df2, df1);
    }

    public static boolean webDateNotLessThan(String date1, String date2) {
        DateFormat df = getNewDateFormat(webFormat);

        return dateNotLessThan(date1, date2, df);
    }

    /**
     * @param date1
     * @param date2
     * @param format
     *
     * @return
     */
    public static boolean dateNotLessThan(String date1, String date2, DateFormat format) {
        try {
            Date d1 = format.parse(date1);
            Date d2 = format.parse(date2);

            if (d1.before(d2)) {
                return false;
            } else {
                return true;
            }
        } catch (ParseException e) {
            return false;
        }
    }

    public static String getEmailDate(Date today) {
        String todayStr;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日HH:mm:ss");

        todayStr = sdf.format(today);
        return todayStr;
    }

    public static String getSmsDate(Date today) {
        String todayStr;
        SimpleDateFormat sdf = new SimpleDateFormat("MM月dd日HH:mm");

        todayStr = sdf.format(today);
        return todayStr;
    }

    public static String formatMonth(Date date) {
        if (date == null) {
            return null;
        }

        return new SimpleDateFormat(monthFormat).format(date);
    }

    /**
     * 获取系统日期的前一天日期，返回Date
     *
     * @return
     */
    public static Date getBeforeDate() {
        Date date = new Date();

        return new Date(date.getTime() - (ONE_DAY_MILL_SECONDS));
    }

    /**
     * 获得指定时间当天起点时间
     * 
     * @param date
     * @return
     */
    public static Date getDayBegin(Date date) {
        DateFormat df = new SimpleDateFormat("yyyyMMdd");
        df.setLenient(false);

        String dateString = df.format(date);

        try {
            return df.parse(dateString);
        } catch (ParseException e) {
            return date;
        }
    }

    /**
     * 判断参date上min分钟后，是否小于当前时间
     * @param date
     * @param min
     * @return
     */
    public static boolean dateLessThanNowAddMin(Date date, long min) {
        return addMinutes(date, min).before(new Date());

    }

    /**
     * 判断参date上sec秒后，是否小于当前时间
     * @param date
     * @param sec
     * @return
     */
    public static boolean dateLessThanNowAddSeconds(Date date, long sec) {
        return addSeconds(date, sec).before(new Date());
    }

    public static boolean isBeforeNow(Date date) {
        if (date == null)
            return false;
        return date.compareTo(new Date()) < 0;
    }

    public static Date parseNoSecondFormat(String sDate) throws ParseException {
        DateFormat dateFormat = new SimpleDateFormat(noSecondFormat);

        if ((sDate == null) || (sDate.length() < noSecondFormat.length())) {
            throw new ParseException("length too little", 0);
        }

        if (!StringUtils.isNumeric(sDate)) {
            throw new ParseException("not all digit", 0);
        }

        return dateFormat.parse(sDate);
    }

    public static String parseDateToString(Date date) {
        try {
            final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return sdf.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    /**
     * 获取当天是星期几
     * @return
     */
    public static int getWeekDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int weekDay = calendar.get(Calendar.DAY_OF_WEEK);
        if (weekDay == 1) {
            return 7;
        }
        return weekDay - 1;
    }
    
    /**
     * 获取当前日期是星期几<br>
     * 
     * @param dt
     * @return 当前日期是星期几
     */
    public static String getWeekOfDate(Date dt) {
        String[] weekDays = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
        Calendar cal = Calendar.getInstance();
        cal.setTime(dt);
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0)
            w = 0;
        return weekDays[w];
    }

    /**
     * 格式化日期
     * @param date
     * @param dayFormat
     * @return
     */
    public static String getDayFormat(Date date, String dayFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(dayFormat);
        return sdf.format(date);
    }

    public static Date getDate(String dateStr, String dayFormat) {
        SimpleDateFormat sdf = new SimpleDateFormat(dayFormat);
        try {
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new Date();
    }

    /**
     * 获取两个日期相差的天数
     * @param smdate
     * @param bdate
     * @return
     * @throws ParseException
     */
    public static int daysBetween(String smdate, String bdate) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Calendar cal = Calendar.getInstance();
            cal.setTime(sdf.parse(smdate));
            long time1 = cal.getTimeInMillis();
            cal.setTime(sdf.parse(bdate));
            long time2 = cal.getTimeInMillis();
            Long between_days = (time2 - time1) / (1000 * 3600 * 24);
            return between_days.intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 获取两个日期相差的天数
     * @param smdate
     * @param bdate
     * @return
     * @throws ParseException
     */
    public static int daysBetweenForDate(Date smdate, Date bdate) {
        try {
        	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");  
            smdate=sdf.parse(sdf.format(smdate));  
            bdate=sdf.parse(sdf.format(bdate));  
            Calendar cal = Calendar.getInstance();    
            cal.setTime(smdate);    
            long time1 = cal.getTimeInMillis();                 
            cal.setTime(bdate);    
            long time2 = cal.getTimeInMillis();         
            long between_days=(time2-time1)/(1000*3600*24);  
                
           return Integer.parseInt(String.valueOf(between_days)); 
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 获取两个时间在日期上的差异 比如 2014-01-01 23:59:59 和2014-01-02 0：0：0 相差-1 
     * @param smdate  减日期
     * @param bdate  被减日期
     * @return   0 相同， 其他为正负差异, 
     * 
     */
    public static int daysDiffForDate(Date smdate, Date bdate) {
        try {
            Calendar cal = Calendar.getInstance();
            cal.setTime(smdate);
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            long time1 = cal.getTimeInMillis();
            cal.setTime(bdate);
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);

            long time2 = cal.getTimeInMillis();
            Long between_days = (time2 - time1) / (1000 * 3600 * 24);
            return between_days.intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 获取两个日期相差的天数
     * @param smdate
     * @param bdate
     * @return
     * @throws ParseException
     */
    public static int hoursBetweenForDate(Date smdate, Date bdate) {
        try {
            long time1 = smdate.getTime();
            long time2 = bdate.getTime();
            Long between_days = (time2 - time1) / (1000 * 3600);
            return between_days.intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static Long getTodayZeroTime() {
        try {
            Date date = new Date();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH), 0, 0, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            return calendar.getTimeInMillis();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0l;
    }

    public static Long getTodayMaxTime() {
        try {
            Date date = new Date();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH), 23, 59, 59);
            calendar.set(Calendar.MILLISECOND, 999);
            return calendar.getTimeInMillis();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0l;
    }
    
    public static Long getTodayMaxTime(Date date) {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH), 23, 59, 59);
            calendar.set(Calendar.MILLISECOND, 999);
            return calendar.getTimeInMillis();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0l;
    }

    public static long getCalendayBuyDiffHour(String startTime) {
        try {
            Date startDate = getDate(startTime, "yyyy-MM-dd HH");
            long diffTimes = (new Date().getTime() - startDate.getTime()) / ONE_HOUR_MILL_TIMES;
            return diffTimes;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0l;
    }

    /**
     * 返回和指定日期相差指定天数的日期
     * @param date
     * @param diffDays(可为负)
     * @return
     */
    public static Date getDesignationDate(Date date, int diffDays) {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_YEAR, diffDays);
            return calendar.getTime();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }

    /**
     * 比较两个日期
     * @param smdate
     * @param bdate
     * @return 0:equal;1 large;-1 less then
     * @throws ParseException
     */
    public static int compareDate(String smdate, String bdate, String dateFormat) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            if (smdate.equals(bdate))
                return 0;
            boolean comparedValue = sdf.parse(smdate).after(sdf.parse(bdate));
            return comparedValue ? 1 : -1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 和当前时间比较返回差值，毫秒级  大于 则为正 小于则为负数
     * @param smdate
     * @param dateFormat
     * @return
     */
    public static long compareWithNow(String smdate, String dateFormat) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            return sdf.parse(smdate).getTime() - System.currentTimeMillis();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 获取两个日期相差的小时
     * @param smdate
     * @param dateFormat
     * @return
     * @throws ParseException
     */
    public static double hoursBetweenNow(String smdate, String dateFormat) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            long time1 = sdf.parse(smdate).getTime();
            long time2 = System.currentTimeMillis();
            return (time1 - time2) / (1000.0 * 3600.0);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * （当前时间-time）后的时间需要在date之前，返回true，在date之后返回false
     * eg:当前时间=2015-1-13 10:30:00,date=2015-1-13 10:09:00,time=10m
     * 则(当前时间-time)=2015-1-13 10:20:00,在date之后,false
     * 
     * @param date
     * @param time 默认为m，s表示秒，m表示分钟，h表示小时，d表示天
     * @return
     */
    public static boolean timeParseValid(Date date, String time) {
        if (StringUtils.isBlank(time) || time.equals("0")) {
            return true;
        }

        long temp = 0l;
        if (time.contains("s")) {
            temp = Long.parseLong(time.substring(0, time.indexOf("s")));
        } else if (time.contains("m")) {
            temp = Long.parseLong(time.substring(0, time.indexOf("m"))) * 60;
        } else if (time.contains("h")) {
            temp = Long.parseLong(time.substring(0, time.indexOf("h"))) * 60 * 60;
        } else if (time.contains("d")) {
            temp = Long.parseLong(time.substring(0, time.indexOf("d"))) * 24 * 60 * 60;
        } else {
            temp = Long.parseLong(time) * 60;
        }

        boolean result = dateLessThanNowAddSeconds(date, temp);
        return !result;
    }

    /**
     * 根据用户生日计算年龄
     */
    public static String getAgeByBirthday(Date birthday) {
        Calendar cal = Calendar.getInstance();

        if (cal.before(birthday)) {
            throw new IllegalArgumentException("The birthDay is before Now.It's unbelievable!");
        }

        int yearNow = cal.get(Calendar.YEAR);
        int monthNow = cal.get(Calendar.MONTH) + 1;
        int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);

        cal.setTime(birthday);
        int yearBirth = cal.get(Calendar.YEAR);
        int monthBirth = cal.get(Calendar.MONTH) + 1;
        int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);
        Calendar lastCal = Calendar.getInstance();
        lastCal.set(yearBirth, monthNow - 2, 1);
        int lastMonthMaxDay = lastCal.getActualMaximum(Calendar.DAY_OF_MONTH);

        int age = yearNow - yearBirth;
        int month = 0;
        int day = 0;

        if (monthNow <= monthBirth) {
            if (monthNow == monthBirth) {
                if (dayOfMonthNow < dayOfMonthBirth) {
                    month = 11;
                    age--;
                    day = dayOfMonthNow + lastMonthMaxDay - dayOfMonthBirth;
                } else {
                    month = 0;
                    day = dayOfMonthNow - dayOfMonthBirth;
                }
            } else {
                age--;
                if (dayOfMonthNow < dayOfMonthBirth) {
                    month = monthNow + 11 - monthBirth;
                    day = dayOfMonthNow + lastMonthMaxDay - dayOfMonthBirth;
                } else {
                    month = monthNow + 12 - monthBirth;
                    day = dayOfMonthNow - dayOfMonthBirth;
                }
            }
        } else {
            if (dayOfMonthNow < dayOfMonthBirth) {
                month = monthNow - monthBirth - 1;
                day = dayOfMonthNow + lastMonthMaxDay - dayOfMonthBirth;
            } else {
                month = monthNow - monthBirth;
                day = dayOfMonthNow - dayOfMonthBirth;
            }
        }
        String result = "";
        if (age > 0) {
            result += age + "岁";
        }
        if (month > 0) {
            result += month + "个月";
        }
        if (day >= 0) {
        	if(StringUtils.isNotBlank(result)){
        		result += "零" + day + "天";
        	}else {
        		result +=  day + "天";
        	}
        }
        return result;
    }

    public static Integer getDiffMonth(Integer unixTime) {
        Long dateTime = Long.valueOf(unixTime) * 1000;
        Calendar cal = Calendar.getInstance();

        if (cal.before(dateTime)) {
            throw new IllegalArgumentException("The birthDay is before Now.It's unbelievable!");
        }

        int yearNow = cal.get(Calendar.YEAR);
        int monthNow = cal.get(Calendar.MONTH) + 1;
        int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);

        cal.setTimeInMillis(dateTime);
        int yearBirth = cal.get(Calendar.YEAR);
        int monthBirth = cal.get(Calendar.MONTH) + 1;
        int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);
        Calendar lastCal = Calendar.getInstance();
        lastCal.set(yearBirth, monthNow - 2, 1);

        int age = yearNow - yearBirth;
        int month = 0;

        if (monthNow <= monthBirth) {
            if (monthNow == monthBirth) {
                if (dayOfMonthNow < dayOfMonthBirth) {
                    month = 11;
                    age--;
                } else {
                    month = 0;
                }
            } else {
                age--;
                if (dayOfMonthNow < dayOfMonthBirth) {
                    month = monthNow + 11 - monthBirth;
                } else {
                    month = monthNow + 12 - monthBirth;
                }
            }
        } else {
            if (dayOfMonthNow < dayOfMonthBirth) {
                month = monthNow - monthBirth - 1;
            } else {
                month = monthNow - monthBirth;
            }
        }

        return age * 12 + month;
    }
    
    public static Integer getDiffMonth(Date startDate , Date endDate){
        Calendar cal = Calendar.getInstance();

        cal.setTimeInMillis(endDate.getTime());

        int yearNow = cal.get(Calendar.YEAR);
        int monthNow = cal.get(Calendar.MONTH) + 1;
        int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);

        cal.setTimeInMillis(startDate.getTime());
        int yearBirth = cal.get(Calendar.YEAR);
        int monthBirth = cal.get(Calendar.MONTH) + 1;
        int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);
        Calendar lastCal = Calendar.getInstance();
        lastCal.set(yearBirth, monthNow-2, 1);

        int age = yearNow - yearBirth;
        int month = 0;
        
        if (monthNow <= monthBirth) {
            if (monthNow == monthBirth) { 
                if (dayOfMonthNow < dayOfMonthBirth) {
                    month = 11;
                    age--;
                }else {
                    month = 0;
                }
            } else {
                age--;
                if (dayOfMonthNow < dayOfMonthBirth) {
                    month = monthNow + 11 - monthBirth;  
                }else{
                    month = monthNow + 12 - monthBirth;
                }
            }
        } else {
            if (dayOfMonthNow < dayOfMonthBirth) {
                month = monthNow-monthBirth-1;
            }else {
                month = monthNow-monthBirth;
            }
        }

        return age*12+month;
    }
    
    /**
     * 获取当前UnixTime
     * @return
     */
    public static Integer getCurrentUnixTime() {
        Long time = new Date().getTime();
        Long unixTimeLong = time / 1000;
        Integer unixTime = unixTimeLong.intValue();
        return unixTime;
    }

    /**
     * 指定时间加上指定月份
     * @param time
     * @param addMonth
     * @return
     */
    public static Long addMonth(Long time, int addMonth) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(time);
        cal.add(Calendar.MONTH, addMonth);
        return cal.getTimeInMillis();
    }

    public static Date parseUnixTimeToDate(Long unixTime) {
        Long dateTime = unixTime * TIMEMILLS;
        return new Date(dateTime);
    }
    
    public static Date parseUnixTimeToDate(Integer unixTime) {
        Long dateTime = Long.valueOf(unixTime * TIMEMILLS);
        return new Date(dateTime);
    }

    /**
     * 获取GMT时间格式的字符串
     * 
     * @param date
     * @return
     */
    public static String getGMCDateString(Date date) {
        DateFormat format = new SimpleDateFormat(GMT_FORMAT);
        format.setTimeZone(TimeZone.getTimeZone(GMT));
        String dateStr = format.format(date);
        return dateStr;
    }
    
    public static String getForumDate(Date date){
    	Calendar cal = Calendar.getInstance();
    	cal.setTime(date);
    	Integer year = cal.get(Calendar.YEAR);
    	Long currentTime = new Date().getTime();
    	cal.setTimeInMillis(currentTime);
    	Integer currentYear = cal.get(Calendar.YEAR);
    	Long time = date.getTime();
    	if(currentTime-time<3*60*1000){
    		//3分钟之内显示刚刚
    		return "刚刚";
    	}else if(currentTime-time < 60*60*1000){
    		//1小时内显示分钟数
    		int minute = (int) ((currentTime-time)/(1000*60));
    		return minute+"分钟前";
    	}else if(time>=getTodayZeroTime()){
    		return format(date, HOUR_MINUTE_Format);
    	}else if(time<getTodayZeroTime()&&currentYear>=year){
    		return format(date, MONTH_DAY_Format);
    	}else {
    		return format(date, webFormat);
    	}
    }
    
    public static Integer getTodayMaxUnixTime(){
    	Long longMaxTime = getTodayMaxTime();
    	Integer unixMaxTime  = (int) (longMaxTime/1000);
    	return unixMaxTime;
    }
    
    public static Long getTodayMinUnixTime(){
    	Long longZeroTime = getTodayZeroTime();
    	Long unixZeroTime  = (longZeroTime/1000);
    	return unixZeroTime;
    }
    
    public static Boolean isBirthDay(Date date){
        Calendar cal = Calendar.getInstance();

        int yearNow = cal.get(Calendar.YEAR);
        int monthNow = cal.get(Calendar.MONTH) + 1;
        int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);

        cal.setTime(date);
        int yearBirth = cal.get(Calendar.YEAR);
        int monthBirth = cal.get(Calendar.MONTH) + 1;
        int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);
    	if(yearBirth<yearNow&&monthBirth==monthNow&&dayOfMonthNow==dayOfMonthBirth){
    		return true;
    	}
        return false;
     }

    
    public static Integer getBirth(Date date){
        Calendar cal = Calendar.getInstance();

        int yearNow = cal.get(Calendar.YEAR);
        int monthNow = cal.get(Calendar.MONTH) + 1;
        int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);

        cal.setTime(date);
        int yearBirth = cal.get(Calendar.YEAR);
        int monthBirth = cal.get(Calendar.MONTH) + 1;
        int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);
    	if(yearBirth<yearNow&&monthBirth==monthNow&&dayOfMonthNow==dayOfMonthBirth){
    		return yearNow-yearBirth;
    	}
        return 0;
     }
    
    /**
     * 获取指定日期的23点的时间
     */
    public static Date get23HourOfDay(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.set(Calendar.HOUR, 23);
        Date date23 = c.getTime();
        return date23;
    }
    
    /**
     * 判断指定日期的格式是否合法<br>
     */
    public static boolean isValid(String date, String pattern) {
        Date d = parseDate(date, pattern);
        return d != null && format(d, pattern).equals(date);
    }
    
    /**
     * 计算相对年<br>
     * amount可以为负数
     *
     */
    public static Date addYears(Date date, int amount) {
        return DateUtils.addYears(date, amount);
    }

    /**
     * 计算相对月<br>
     * amount可以为负数
     */
    public static Date addMonths(Date date, int amount) {
        return DateUtils.addMonths(date, amount);
    }

    /**
     * 计算相对日<br>
     * amount可以为负数
     */
    public static Date addDays(Date date, int amount) {
        return DateUtils.addDays(date, amount);
    }

    /**
     * 计算相对毫秒<br>
     * amount可以为负数
     */
    public static Date addMilliseconds(Date date, int amount) {
        return DateUtils.addMilliseconds(date, amount);
    }

    /**
     * 计算相对星期
     */
    public static Date addWeeks(Date date, int amount) {
        return DateUtils.addWeeks(date, amount);
    }
    
    /**
     *  计算时间跨度<br>
     *  计算方式：结束时间减开始时间
     */
    public static long getTimeSpan(Date begin, Date end, int type) {
        long diff = end.getTime() - begin.getTime();
        switch (type) {
            case DAY:
            default:
                return diff / DateUtils.MILLIS_PER_DAY;
            case HOUR:
                return diff / DateUtils.MILLIS_PER_HOUR;
            case MINUTE:
                return diff / DateUtils.MILLIS_PER_MINUTE;
            case SECOND:
                return diff / DateUtils.MILLIS_PER_SECOND;
        }
    }
    
    /**
     * 获得日期差<br>
     * 不足一天的忽略
     *
     */
    public static long getDaySpan(Date begin, Date end) {
        return getTimeSpan(begin, end, DAY);
    }

    /**
     * 获得小时差<br>
     * 不足一小时的忽略
     *
     */
    public static long getHourSpan(Date begin, Date end) {
        return getTimeSpan(begin, end, HOUR);
    }

    /**
     * 获得分钟差<br>
     * 不足一分钟的忽略
     *
     */
    public static long getMinuteSpan(Date begin, Date end) {
        return getTimeSpan(begin, end, MINUTE);
    }

    /**
     * 获得秒差<br>
     * 不足一秒的忽略
     *
     
     */
    public static long getSecondSpan(Date begin, Date end) {
        return getTimeSpan(begin, end, SECOND);
    }

    /**
     * 获取月份差
     *
     */
    public static int getMonthSpan(Date begin, Date end) {
        Calendar beginCal = new GregorianCalendar();
        beginCal.setTime(begin);
        Calendar endCal = new GregorianCalendar();
        endCal.setTime(end);
        int m = (endCal.get(Calendar.MONTH)) - (beginCal.get(Calendar.MONTH));
        int y = (endCal.get(Calendar.YEAR)) - (beginCal.get(Calendar.YEAR));
        return y * 12 + m;
    }
    
    public static Date getDayEnd(Date date){
        DateFormat df = new SimpleDateFormat("yyyyMMdd");
        df.setLenient(false);

        System.out.println(df.format(date));
        return parseDate(df.format(date) + "235959");
       
    }
}
