package com.fcbox.util.common;

import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * 字符串工具类, 继承org.apache.commons.lang3.StringUtils类
 */
public class StringUtils extends org.apache.commons.lang3.StringUtils {

    private static final Logger logger = LoggerFactory.getLogger(StringUtils.class);

    public static String lowerFirst(String str) {
        if (StringUtils.isBlank(str)) {
            return "";
        } else {
            return str.substring(0, 1).toLowerCase() + str.substring(1);
        }
    }

    public static String upperFirst(String str) {
        if (StringUtils.isBlank(str)) {
            return "";
        } else {
            return str.substring(0, 1).toUpperCase() + str.substring(1);
        }
    }

    /**
     * 替换掉HTML标签方法
     */
    public static String replaceHtml(String html) {
        if (isBlank(html)) {
            return "";
        }
        String regEx = "<.+?>";
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(html);
        return matcher.replaceAll("");
    }

    /**
     * 缩略字符串（不区分中英文字符）
     *
     * @param str 目标字符串
     * @param length 截取长度
     */
    public static String abbr(String str, int length) {
        if (str == null) {
            return "";
        }
        try {
            StringBuilder sb = new StringBuilder();
            int currentLength = 0;
            for (char c : replaceHtml(StringEscapeUtils.unescapeHtml4(str)).toCharArray()) {
                currentLength += String.valueOf(c).getBytes("GBK").length;
                if (currentLength <= length - 3) {
                    sb.append(c);
                } else {
                    sb.append("...");
                    break;
                }
            }
            return sb.toString();
        } catch (UnsupportedEncodingException e) {
            logger.error("缩略字符串异常", e);
        }
        return "";
    }

    /**
     * 缩略字符串（替换html）
     *
     * @param str 目标字符串
     * @param length 截取长度
     */
    public static String rabbr(String str, int length) {
        return abbr(replaceHtml(str), length);
    }


    /**
     * 转换为Double类型
     */
    public static Double toDouble(Object val) {
        if (val == null) {
            return 0D;
        }
        try {
            return Double.valueOf(trim(val.toString()));
        } catch (Exception e) {
            return 0D;
        }
    }

    /**
     * 转换为Float类型
     */
    public static Float toFloat(Object val) {
        return toDouble(val).floatValue();
    }

    /**
     * 转换为Long类型
     */
    public static Long toLong(Object val) {
        return toDouble(val).longValue();
    }

    /**
     * 转换为Integer类型
     */
    public static Integer toInteger(Object val) {
        return toLong(val).intValue();
    }

    /**
     * @param str 被判断字符串
     * @return 判断结构
     * @desc 判断一个字符串是否为空或者null
     */
    public static boolean isNullOrEmpty(String str) {
        if (str == null) {
            return true;
        }
        return "".equals(str.trim());
    }

    /**
     * @param cs 多个字符串
     * @return boolean
     * @desc 检测全部参数是否为空，有一个为空则返回false，全部都不为空则返回true
     */
    public static boolean isNotEmptyAll(CharSequence... cs) {
        for (CharSequence charSequence : cs) {
            //出现一个为空就返回false
            if (!isNotEmpty(charSequence)) {
                return false;
            }
        }
        //全部都不为空则返回true
        return true;
    }

    /**
     * 正则验证 add by Laven
     *
     * @param regex 正则
     * @param content 验证内容
     * @return 验证结果
     */
    public static boolean checkRegex(String regex, String content) {
        if (StringUtils.isEmpty(content)) {
            return false;
        }
        return Pattern.compile(regex).matcher(content).matches();
    }


    /**
     * 长度验证，如果字符串长度大于length则验证不通过
     *
     * @param str 验证字符串
     * @param length 验证长度
     * @return 验证结果
     */
    public static boolean checkLength(String str, int length) {
        int strLength = StringUtils.length(str);
        return length >= strLength;
    }


}
