package com.fcbox.util.kit;

import com.fcbox.util.constant.UtilConstant;
import org.apache.commons.lang3.StringUtils;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright:
 * createTime: 2018/10/22 20:29
 * modifyTime:
 * modifyBy:
 */
public class StringKit extends StringUtils {

    /**
     * 判断字符串是否为空，从apache common lang3.5里面摘取
     *
     * @param cs
     * @return
     */
    public static boolean isBlank(CharSequence cs) {
        int strLen;
        if (cs != null && (strLen = cs.length()) != 0) {
            for (int i = 0; i < strLen; ++i) {
                if (!Character.isWhitespace(cs.charAt(i))) {
                    return false;
                }
            }

            return true;
        } else {
            return true;
        }
    }

    public static boolean isNotBlank(CharSequence cs) {
        return !isBlank(cs);
    }

    public static String join(String[] stringArray) {
        StringBuilder sb = new StringBuilder();
        for (String s : stringArray)
            sb.append(s);
        return sb.toString();
    }

    public static String join(String[] stringArray, String separator) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < stringArray.length; i++) {
            if (i > 0)
                sb.append(separator);
            sb.append(stringArray[i]);
        }
        return sb.toString();
    }

    /**
     * 将图片地址换成http(https)完整路径
     *
     * @param imageUrl 图片地址
     * @param host     图片服务器域名
     * @return 图片完整地址
     */
    public static String toFullImageUrl(String host, String imageUrl) {
        if (isBlank(imageUrl)) {
            return EMPTY;
        }
        if (isBlank(host)) {
            return imageUrl;
        }
        imageUrl = imageUrl.replaceAll("\\\\", UtilConstant.BACKSLASH);
        if (imageUrl.startsWith(UtilConstant.BACKSLASH) && imageUrl.length() == 1) {
            return EMPTY;
        }
        if (imageUrl.startsWith(UtilConstant.BACKSLASH)) {
            imageUrl = imageUrl.substring(1);
        }
        if (imageUrl.startsWith("http")) {
            return imageUrl;
        }
        String uploadPath = defaultIfBlank(
                host, EMPTY);
        if (!uploadPath.endsWith(UtilConstant.BACKSLASH)) {
            uploadPath += UtilConstant.BACKSLASH;
        }
        return uploadPath + imageUrl;
    }

    /**
     * 获取url的pathname,url去除域名和querystring部分
     *
     * @param url http url
     * @return pathname
     */
    public static String getUrlPathName(String url) {
        if (isBlank(url)) {
            return EMPTY;
        }
        int at = url.indexOf("//");
        int from = url.indexOf("/", at >= 0 ? (url.lastIndexOf("/", at - 1) >= 0 ? 0 : at + 2) : 0);
        int to = url.length();
        if (url.indexOf('?', from) != -1) {
            to = url.indexOf('?', from);
        }
        if (url.lastIndexOf("#") > from && url.lastIndexOf("#") < to) {
            to = url.lastIndexOf("#");
        }
        return (from < 0) ? (at >= 0 ? "/" : url) : url.substring(from, to);
    }

}
