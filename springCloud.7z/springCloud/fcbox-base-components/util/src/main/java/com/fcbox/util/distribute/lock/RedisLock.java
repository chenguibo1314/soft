package com.fcbox.util.distribute.lock;

import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.ReturnType;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.util.concurrent.TimeUnit;

/**
 * ClassName: RedisLock
 * 
 * @Description: redis锁
 * @author Ningbo.Chen
 * @date 2019/4/30
 *
 */
@Slf4j
public class RedisLock {
    private static final String lockKeyPrefix = "redisLock_";

    private static final int DEFAULT_ACQUIRY_RESOLUTION_MILLIS = 100;

    /**
     * 释放锁lua脚本
     */
    private static final String RELEASE_LOCK_LUA_SCRIPT = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end";

    /**
     * 尝试获取分布式锁
     * @param redisTemplate 客户端
     * @param lockKey 加锁key
     * @param uinqueId 锁的value值，必须唯一
     * @param leaseTime 过期时间,单位：秒
     * @return 是否获取成功
     */
    public static boolean acquire(RedisTemplate redisTemplate, String lockKey, String uinqueId, long leaseTime) {
        String key = lockKeyPrefix.concat(lockKey);
        return redisTemplate.opsForValue().setIfAbsent(key,uinqueId,leaseTime,TimeUnit.SECONDS);
    }

    /**
     * 尝试获取分布式锁
     * @param redisTemplate 客户端
     * @param lockKey 加锁key
     * @param uinqueId 锁的value值，必须唯一
     * @param waitTime 尝试获取锁时间,该段时间内会不断尝试获取锁,单位：秒
     * @param leaseTime 过期时间,单位：秒
     * @return 是否获取成功
     */
    public static boolean acquire(RedisTemplate redisTemplate, String lockKey, String uinqueId,long waitTime, long leaseTime) {
        String key = lockKeyPrefix.concat(lockKey);
        long mSecond = waitTime*1000;
        while(mSecond > 0){
            if(redisTemplate.opsForValue().setIfAbsent(key,uinqueId,leaseTime,TimeUnit.SECONDS)){
                return true;
            }
            mSecond -= DEFAULT_ACQUIRY_RESOLUTION_MILLIS;
            try {
                Thread.sleep(DEFAULT_ACQUIRY_RESOLUTION_MILLIS);
            } catch (InterruptedException e) {
                log.error("acquire lock error,key:{},exception:{}",key,e.getMessage());
            }

        }
        return false;
    }

    /**
     *
     * @param redisTemplate 客户端
     * @param lockKey 释放锁的key
     * @param uinqueId 释放锁的value值，必须与加锁时设置的value值相同才能成功释放锁
     */
    public static void release(RedisTemplate redisTemplate, String lockKey, String uinqueId){
        String key = lockKeyPrefix.concat(lockKey);
        redisTemplate.execute(
                (RedisConnection connection) -> connection.eval(
                        RELEASE_LOCK_LUA_SCRIPT.getBytes(),
                        ReturnType.INTEGER,
                        1,
                        key.getBytes(),
                        uinqueId.getBytes())
        );
    }
}
