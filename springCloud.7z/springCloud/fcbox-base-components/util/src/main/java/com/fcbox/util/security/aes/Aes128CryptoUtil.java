/**
 * 对公众平台发送给公众账号的消息加解密示例代码.
 *
 * @copyright Copyright (c) 1998-2014 Tencent Inc.
 */

// ------------------------------------------------------------------------

package com.fcbox.util.security.aes;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 * AES128-ECB加密
 * kingdee签名接口.
 *
 * @author chenbin
 */
public final class Aes128CryptoUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(Aes128CryptoUtil.class);

    private Aes128CryptoUtil() {
    }


    /**
     * 加密
     *
     * @param content    加密内容
     * @param encryptKey 加密密码
     * @return
     * @throws Exception
     */
    public static String encrypt(String content, String encryptKey) throws Exception {

        if (StringUtils.isEmpty(encryptKey)) {
            LOGGER.info("加密密码不能为空");
            return StringUtils.EMPTY;
        }
        // 判断Key是否为16位
        if (encryptKey.length() != 16) {
            LOGGER.info("encryptKey长度不是16位");
            return StringUtils.EMPTY;
        }
        byte[] raw = encryptKey.getBytes("utf-8");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");// "算法/模式/补码方式"
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        byte[] encrypted = cipher.doFinal(content.getBytes("utf-8"));
        return new Base64().encodeToString(encrypted);//此处使用BASE64做转码功能，同时能起到2次加密的作用。
    }

    /**
     * 解密
     *
     * @param content    解密内容
     * @param decryptKey 解密密码
     * @return
     * @throws Exception
     */
    public static String decrypt(String content, String decryptKey) throws Exception {
        if (StringUtils.isEmpty(decryptKey)) {
            LOGGER.info("解密密码decryptKey不能为空");
            return StringUtils.EMPTY;
        }
        // 判断Key是否为16位
        if (decryptKey.length() != 16) {
            LOGGER.info("decryptKey长度不是16位");
            return StringUtils.EMPTY;
        }
        byte[] raw = decryptKey.getBytes("utf-8");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, skeySpec);
        byte[] encrypted1 = new Base64().decode(content);//先用base64解密
        byte[] original = cipher.doFinal(encrypted1);
        return new String(original, "utf-8");
    }
}
