package com.fcbox.util.common;

import com.fcbox.util.converter.LocalDateTimeAndDateConverter;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

import java.util.List;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/4/6 16:45
 * modifyTime:
 * modifyBy:
 */
public class CopyAttributesUtils {

    public static MapperFactory factory = null;

    public static MapperFactory getFactoryInstance(){
        synchronized (MapperFactory.class) {
            if(factory == null){
//                System.setProperty(OrikaSystemProperties.COMPILER_STRATEGY, EclipseJdtCompilerStrategy.class.getName());
                factory = new DefaultMapperFactory.Builder().build();
                factory.getConverterFactory().registerConverter(new LocalDateTimeAndDateConverter());
            }
        }
        return factory;
    }

    /**
     * @param sourceObject
     * @param destinationClass
     * @param <S>
     * @param <D>
     * @return
     */
    public static <S, D> D copyAtoB(S sourceObject, Class<D> destinationClass) {
        return getFactoryInstance().getMapperFacade().map(sourceObject, destinationClass);
    }

    /**
     * @param source
     * @param destinationClass
     * @param <S>
     * @param <D>
     * @return
     */
    public static <S, D> List<D> copyAlistToBlist(Iterable<S> source, Class<D> destinationClass) {
        return getFactoryInstance().getMapperFacade().mapAsList(source, destinationClass);
    }


}
