package com.fcbox.util.orika;

import com.fcbox.util.domain.UserModelDto;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import com.fcbox.util.common.CopyAttributesUtils;
import com.fcbox.util.domain.UserModel;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/11/27 9:47
 * modifyTime:
 * modifyBy:
 */
public class TestOrika {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Test
    public void testOrikaCopy() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(UserModel.class, UserModelDto.class)
                .field("account", "account")
                .field("nickName", "nickName")
                .byDefault()
                .register();

        UserModel userModel = new UserModel();
        userModel.setAccount("phil");
        userModel.setNickName("菲尔");
        userModel.setCreateTime(LocalDateTime.now());

        MapperFacade mapper = mapperFactory.getMapperFacade();

        UserModelDto userModelDto = mapper.map(userModel, UserModelDto.class);
        LOGGER.info("userModelDto:{}", userModelDto);
    }

    @Test
    public void testOrikaCopy2() {
        UserModel userModel = new UserModel();
        userModel.setAccount("phil");
        userModel.setNickName("菲尔");
        userModel.setCreateTime(LocalDateTime.now());
        LOGGER.info("map1:{}", map1(userModel));
    }

    /**
     * 相同属性的复制
     *
     * @param userModel
     * @return
     */
    public static UserModelDto map1(UserModel userModel) {
        //since filed name is same, so no need to register
        MapperFactory factory = new DefaultMapperFactory.Builder().build();
        UserModelDto userModelDto = new UserModelDto();
        //userModelDto = factory.getMapperFacade(UserModel.class, UserModelDto.class).map(userModel);
        factory.getMapperFacade().map(userModel, userModelDto);
        return userModelDto;
    }

    @Test
    public void testOrikaCopy3() {
        UserModel userModel = new UserModel();
        userModel.setAccount("phil");
        userModel.setNickName("菲尔");
        userModel.setCreateTime(LocalDateTime.now());
        UserModelDto userModelDto = CopyAttributesUtils.copyAtoB(userModel, UserModelDto.class);
        LOGGER.info("map3:{}", userModelDto);
    }

    @Test
    public void testOrikaCopy4() {
        List<UserModel> userModelList = new ArrayList<>();
        UserModel userModel = new UserModel();
        userModel.setAccount("phil");
        userModel.setNickName("菲尔");
        userModel.setCreateTime(LocalDateTime.now());
        userModelList.add(userModel);

        UserModel userModel2 = new UserModel();
        userModel2.setAccount("phil2");
        userModel2.setNickName("菲尔2");
        userModel2.setCreateTime(LocalDateTime.now());
        userModelList.add(userModel2);

        List<UserModelDto> userModelDtoList = CopyAttributesUtils.copyAlistToBlist(userModelList, UserModelDto.class);
        LOGGER.info("map4:{}", userModelDtoList);
    }

}
