package com.fcbox.util.random;

import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

/**
 * @version: v1.0
 * @author: Haixiang.Dai
 * project: ssxs-
 * copyright: SSXINGSHOU TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/11/28 15:06
 * modifyTime:
 * modifyBy:
 */
public class RandomUtil {

    /**
     *
     */
    @Test
    public void testRandom() {
        int parentlistSize = 3;
        int recommendedSize = 5;
        int parentIndex = 0;
        Set<Integer> parentIndexs = new HashSet<>();
        while (recommendedSize > 0) {
            parentIndex = (int) (Math.random() * (parentlistSize));
            System.out.println("parentIndex：" + parentIndex);
            System.out.println("parentIndexs：" + parentIndexs.toString());
            if (parentIndexs.contains(parentIndex)) {
                continue;
            }
            parentIndexs.add(parentIndex);
            recommendedSize--;
            System.out.println("size：" + recommendedSize);
        }
    }

}
