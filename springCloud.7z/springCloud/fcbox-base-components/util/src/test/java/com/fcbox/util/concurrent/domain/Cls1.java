/**
 * 
 */
package com.fcbox.util.concurrent.domain;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class Cls1 {

	/**
	 * 可以看到a没有任何依赖。
	 */
	private int a;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

}
