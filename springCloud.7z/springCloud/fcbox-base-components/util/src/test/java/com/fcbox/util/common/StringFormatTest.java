/**
 * 
 */
package com.fcbox.util.common;

/**
 * JAVA String.format 方法使用介绍
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class StringFormatTest {
	
	public static void main(String[] args) {
		String releasedTime = "2010年";
		System.out.println(releasedTime.replaceAll("年", ""));
	}

}
