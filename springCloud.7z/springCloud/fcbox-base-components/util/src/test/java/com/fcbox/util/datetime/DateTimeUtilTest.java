package com.fcbox.util.datetime;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * @version: v1.0
 * @author: Haixiang.Dai
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/4/13 11:39
 * modifyTime:
 * modifyBy:
 */
public class DateTimeUtilTest {
    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Test
    public void testIsEquals() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime cur = DateTimeUtil.buildStringToLocalDateTime("2018-03-29 16:39:10");

        boolean isCorrect = now.isEqual(cur);
        LOGGER.info("{}", isCorrect);
    }

    @Test
    public void testLong() {
        LocalDateTime myTime = DateTimeUtil.buildLongToLocalDateTime(1505825061);
        LOGGER.info("myTime:{}", DateTimeUtil.buildLocalDateTimeToString(myTime));

        LocalDateTime now = LocalDateTime.now();
        long nowLong = now.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        LOGGER.info("nowLong:{}", nowLong);
    }

}
