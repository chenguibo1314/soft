package com.fcbox.util.security;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @version: v1.0
 * @author: Haixiang.Dai
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class RSACryptoUtilTest {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Test
    public void testRSA() {
        String aesKey = "fcbox.net";
        String rsaPairFilePath = "/data0/rsaHome/rsatest";

        //tring rsa = "5a727cf4d5aa32cd645633e6558f6187a15a80f7b1451b7ee0cf7acdd273add4d268b8d03743ced6c99da31241adeae6056d115d45802f70cccfeb82d55c8b642b14ee2275e20ec005dbd393fd5b31aa8ddfb3dffabd424698c2e4be81d7a6fd79c05d974b35a2e881fa960489224d99a2f84dba9e76c80c5fb494d82ef05e59";
        //String aesKeyRSA = RSACryptoUtil.decryptString(rsa);
        //LOGGER.info("aesKeyRSA:{}", aesKeyRSA);

        String rsaStr = RSACryptoUtil.encryptString(aesKey, rsaPairFilePath);
        LOGGER.info("rsaStr:{},rsaPairFilePath:{}", rsaStr, rsaPairFilePath);
        String aesKeyRSA = RSACryptoUtil.decryptString(rsaStr, rsaPairFilePath);
        LOGGER.info("aesKeyRSA:{},rsaPairFilePath:{}", aesKeyRSA, rsaPairFilePath);

    }

}
