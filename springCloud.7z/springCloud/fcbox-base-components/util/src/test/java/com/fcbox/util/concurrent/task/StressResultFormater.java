/**
 * 
 */
package com.fcbox.util.concurrent.task;

import java.io.Writer;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public interface StressResultFormater {

	void format(StressResult stressResult, Writer writer);

}
