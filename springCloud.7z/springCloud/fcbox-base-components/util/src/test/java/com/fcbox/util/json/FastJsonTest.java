/**
 *
 */
package com.fcbox.util.json;

import com.alibaba.fastjson.JSON;
import com.fcbox.util.domain.LocalDateTimeModel;
import com.fcbox.util.domain.UserModel;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright:
 * createTime: 2018/6/29 21:10
 * modifyTime:
 * modifyBy:
 */
public class FastJsonTest {
    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    /**
     * 测试java转json时，当属性为null或者空时，不转化此参数key(就是忽略此属性)。
     *
     * @version V1.0
     * @author Ningbo.Chen <br>
     * createTime: 2012-11-14 下午3:51:51
     */
    @Test
    public void testJavaObjectToJsonWhilePropertyWasNull() {
        UserModel userModel = new UserModel();
        userModel.setAccount("hello");
        Object str = JSON.toJSON(userModel);
        LOGGER.info(str.toString());
    }

    @Test
    public void testLocalDateTime() {
        LocalDateTimeModel localDateTimeModel = new LocalDateTimeModel();
        localDateTimeModel.setStartDateTime(LocalDateTime.now());
        localDateTimeModel.setEndDateTime(LocalDateTime.now().plusDays(1));

        // to json
        String localDateTimeStr = localDateTimeModel.toString();
        LOGGER.info("localDateTimeStr:{}", localDateTimeStr);

        // to javaobject
        LocalDateTimeModel localDateTimeModelInJson = JSON.parseObject(localDateTimeStr, LocalDateTimeModel.class);
        LOGGER.info("localDateTimeStr:{}", localDateTimeModelInJson);

    }

}
