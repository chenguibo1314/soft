package com.fcbox.util.common;

import org.junit.Test;

import java.util.regex.Pattern;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/12/9 15:20
 * modifyTime:
 * modifyBy:
 */
public class PatternTest {

    @Test
    public void testPattern() {
        //String regexp = "^(?=.*?\\d)(?=.*?[A-Za-z])[\\dA-Za-z]{8,}$";
        String regexp = "^(?=.*?[A-Za-z])[\\dA-Za-z]{8,}$";
        String password = "dhx_1xxx.ss";

        boolean matchesTrue = Pattern.matches(regexp, password);
        System.out.println("matchesTrue:" + matchesTrue);
    }

}
