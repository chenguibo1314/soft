/**
 * 
 */
package com.fcbox.util.gson;

import org.junit.Test;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class DataTypeTest {

	/**
	 * 
	 * 基本的 Java 类型（boolean、byte、char、short、int、long、float 和 double） <br>
	 * 和关键字 void也表示为 Class 对象。<br>
	 * 代表Class类的不同实例<br>
	 * 
	 * @version V1.0.0
	 * @author Ningbo.Chen <br>
	 *         createTime: 2012-4-28 下午2:44:43
	 */
	@Test
	public void testDataType() {
		Class<Integer> c = int.class;
		Class<Integer> c0 = Integer.class;
		System.out.println(c + " : " + c0);
		System.out.println(c.getName() + " : " + c0.getName());
	}

	@Test
	public void testIntClass() throws Exception {
		Class<Integer> clazz = int.class;
		System.out.println(clazz.getConstructors().length);
		System.out.println(clazz);
	}
}
