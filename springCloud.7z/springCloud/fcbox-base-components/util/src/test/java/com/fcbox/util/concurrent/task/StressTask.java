/**
 * 
 */
package com.fcbox.util.concurrent.task;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public interface StressTask {

	Object doTask() throws Exception;

}
