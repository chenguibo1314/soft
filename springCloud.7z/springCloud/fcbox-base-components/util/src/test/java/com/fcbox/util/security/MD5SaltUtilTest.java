package com.fcbox.util.security;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @version: v1.0
 * @author: Haixiang.Dai
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class MD5SaltUtilTest {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Test
    public void testGetMd5Str() {
        String pwdInput = MD5SaltUtil.getEncryptedPwd("fcbox");
        LOGGER.info("pwdInput:{}", pwdInput);
        boolean validPassword = MD5SaltUtil.validPassword("fcbox", "8F32BF3CFBB3F640CE4359051BFAAA70D9FFEC52831FE0B3B7677416");
        LOGGER.info("validPassword:{}", validPassword);
    }
}
