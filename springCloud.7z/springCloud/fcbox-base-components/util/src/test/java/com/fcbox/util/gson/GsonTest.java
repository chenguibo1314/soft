/**
 * 
 */
package com.fcbox.util.gson;

import com.alibaba.fastjson.JSON;
import com.google.gson.Gson;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class GsonTest {

	private final Logger LOGGER = LoggerFactory.getLogger(getClass());

	@Test
	public void test() {
		List<Person> persons = new ArrayList<Person>();
		for (int i = 0; i < 100; i++) {
			Person p = new Person();
			List<FilmDO> filmList = new ArrayList<FilmDO>();
			for (int k = 0; k < 50; k++) {
				FilmDO film = new FilmDO();
				film.setId(k);
				film.setName("name" + k);
				filmList.add(film);
			}
			p.setFilmList(filmList);
			p.setName("name" + i);
			p.setAge(i * 5);
			persons.add(p);
		}
		long beginTime2 = System.currentTimeMillis();
		String str2 = JSON.toJSONString(persons);
		LOGGER.info(str2);
		long endTime2 = System.currentTimeMillis();
		long times2 = endTime2 - beginTime2;
		LOGGER.info("times2: {}", times2);
	}

	@Test
	public void testList() {
		Gson gson = new Gson();
		List<Person> persons = new ArrayList<Person>();
		for (int i = 0; i < 100; i++) {
			Person p = new Person();
			List<FilmDO> filmList = new ArrayList<FilmDO>();
			for (int k = 0; k < 50; k++) {
				FilmDO film = new FilmDO();
				film.setId(k);
				film.setName("name" + k);
				filmList.add(film);
			}
			p.setFilmList(filmList);
			p.setName("name" + i);
			p.setAge(i * 5);
			persons.add(p);
		}

		// LOGGER.info(gson.toJsonTree(persons));
		long beginTime = System.currentTimeMillis();
		String str = gson.toJson(persons);
		LOGGER.info(str);
		long endTime = System.currentTimeMillis();
		long times = endTime - beginTime;
		LOGGER.info("times: {} ", times);

		// List<Person> ps = gson.fromJson(str, new TypeToken<List<Person>>() {
		// }.getType());
		// for (int i = 0; i < ps.size(); i++) {
		// Person p = ps.get(i);
		// LOGGER.info(p.toString());
		// }

	}

}
