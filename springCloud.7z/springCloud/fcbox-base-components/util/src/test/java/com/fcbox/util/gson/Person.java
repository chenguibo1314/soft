/**
 * 
 */
package com.fcbox.util.gson;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class Person implements Serializable {

	private static final long serialVersionUID = -6722468793912545777L;

	private String name;

	private int age;

	private List<FilmDO> filmList = new ArrayList<FilmDO>();

	public List<FilmDO> getFilmList() {
		return filmList;
	}

	public void setFilmList(List<FilmDO> filmList) {
		this.filmList = filmList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
