package com.fcbox.util.security;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @version: v1.0
 * @author: Haixiang.Dai
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/7/24 15:25
 * modifyTime:
 * modifyBy:
 */
public class MD5StandardUtilTest {
    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Test
    public void testGetMd5Str() {
        String standardPwd = MD5StandardUtil.MD5Encode("fcbox");
        LOGGER.info("standardPwd:{}", standardPwd);
        boolean validPassword = standardPwd.equals("8F32BF3CFBB3F640CE4359051BFAAA70D9FFEC52831FE0B3B7677416");
        LOGGER.info("validPassword:{}", validPassword);

        String standardPwd2 = MD5StandardUtil.MD5Encode("YANMING42");
        LOGGER.info("standardPwd2:{}", standardPwd2);

    }
}
