package com.fcbox.util.security.aes;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class BizMsgCryptoUtilTest {
    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Test
    public void test() throws Exception {
        String aesKeyRSA = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFG";
        LOGGER.info("aesKeyRSA:{}", aesKeyRSA);
        String cookiesInfoAES = BizMsgCryptoUtil.encryptMsg(aesKeyRSA, "123456");
        LOGGER.info("cookiesInfoAES:{}", cookiesInfoAES);
        String cookiesInfoAESDec = BizMsgCryptoUtil.decryptMsg(aesKeyRSA, cookiesInfoAES);
        LOGGER.info("cookiesInfoAESDec:{}", cookiesInfoAESDec);
    }

}
