/**
 * 
 */
package com.fcbox.util.concurrent.threadlocal;

/**
 * @version: v1.0
 * @author: Haixiang.Dai
 * project: fcbox-base-component
 * copyright:
 * createTime:
 * modifyTime:
 * modifyBy:
 */
public class Student {

	private int age = 0; // 年龄

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
