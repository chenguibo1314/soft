package com.fcbox.util.common;

import org.junit.Test;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/5/9 23:19
 * modifyTime:
 * modifyBy:
 */
public class FlagBitUtilTest {

    @Test
    public void testQuery(){

    }

}
