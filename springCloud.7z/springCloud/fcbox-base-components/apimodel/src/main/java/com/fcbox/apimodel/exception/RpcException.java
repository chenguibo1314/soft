package com.fcbox.apimodel.exception;

/**
 * RPC异常类
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/19
 **/
public class RpcException extends Exception {
	private static final long serialVersionUID = 356381812673914209L;
	private int errorCode;
	private String projectName;

	public RpcException(String projectName, String msg) {
		super(msg);
		this.projectName = projectName;
	}

	public RpcException(String projectName, Throwable cause) {
		super(cause);
		this.projectName = projectName;
	}

	public RpcException(String projectName, String msg, Throwable cause) {
		super(msg, cause);
		this.projectName = projectName;
	}

	public RpcException(String projectName, int errorCode, String msg) {
		super(msg);
		this.errorCode = errorCode;
		this.projectName = projectName;
	}

	public RpcException(int errorCode, String msg, String projectName,
			Throwable cause) {
		super(msg, cause);
		this.errorCode = errorCode;
		this.projectName = projectName;
	}

	public int getErrorCode() {
		return this.errorCode;
	}

	public String getProjectName() {
		return this.projectName;
	}
}
