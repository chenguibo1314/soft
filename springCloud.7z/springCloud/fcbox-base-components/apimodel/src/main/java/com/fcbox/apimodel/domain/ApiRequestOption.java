package com.fcbox.apimodel.domain;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;

import java.io.Serializable;

/**
 * 发起api请求时的参数封装，提供基本的需求和扩展，并进行规范化。
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: ssxingshou-base-component
 * copyright: SSXINGSHOU TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2019/3/30 13:37
 * modifyTime:
 * modifyBy:
 */
public class ApiRequestOption implements Serializable {
    private static final long serialVersionUID = 144042539117250579L;
    /**
     * api的客户端信息
     */
    private ApiClientInfo info;
    /**
     * api的客户端请求数据
     */
    private Object data;

    public ApiRequestOption() {
    }

    public ApiClientInfo getInfo() {
        return info;
    }

    public void setInfo(ApiClientInfo info) {
        this.info = info;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this, SerializerFeature.DisableCircularReferenceDetect);
    }
}
