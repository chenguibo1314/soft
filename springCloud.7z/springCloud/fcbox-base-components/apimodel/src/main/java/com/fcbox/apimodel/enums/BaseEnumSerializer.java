package com.fcbox.apimodel.enums;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/19
 **/
public class BaseEnumSerializer extends JsonSerializer<BaseEnum> {


	@Override
	@SuppressWarnings("all")
	public void serialize(BaseEnum viewEnum, JsonGenerator jsonGenerator, SerializerProvider serializers)
			throws IOException, JsonProcessingException {
        jsonGenerator.writeStartObject();
        jsonGenerator.writeFieldName("enums");
        jsonGenerator.writeObject(viewEnum.getCode());
        jsonGenerator.writeFieldName("desc");
        jsonGenerator.writeString(viewEnum.getDesc());
        jsonGenerator.writeEndObject();
	}
}
