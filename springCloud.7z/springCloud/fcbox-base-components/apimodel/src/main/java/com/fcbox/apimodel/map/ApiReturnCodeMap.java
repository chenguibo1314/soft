package com.fcbox.apimodel.map;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * api返回码定义规范：（不同的项目自行扩展自此抽象map）
 * <p>
 * 8位数的返回码，00000000，前3位为项目编码，第4+5位为模块编码，后3位为该项目的业务编码。
 * <p>
 * 001开头的为商品业务返回码
 * 002开头的为城市业务返回码{模块代码:基础信息 01、城市截单 02、前台城市设置 03、城市发票设置 04  05、外部物流信息}
 * 003开头的为订单来源业务返回码
 * 004开头的为配送站业务返回码
 * 005开头的为门店业务返回码
 * 006开头的为物流业务返回码
 * 007开头的为图片文件业务返回码
 * 008开头的为订单返回码(模块代码:基础信息01,订单商品信息02,订单拆单04,05订单组合类型,06订单类型)
 * 009开头的为异常订单返回码
 * 010开头的为错误订单返回码
 * 011开头的为退款返回码
 * 012开头的为发票返回码
 * 013开头的为送货单返回码
 * 014开头的为业务返回码...
 * 015开头的为业务返回码...
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2018/8/14 14:27
 * modifyTime:
 * modifyBy:
 */
public abstract class ApiReturnCodeMap {
    /**
     * 成功时，返回码
     */
    public static final String success = "00000000";
    /**
     * 错误时，无实际业务返回码
     */
    public static final String failure = "-1";
    /**
     * 请求参数错误
     */
    public static final String failureParams = "00000001";
    /**
     * 请求参数错误
     */
    public static final String repeatSubmitFailureParams = "00000002";


    public static final Map<String, String> apiReturnCodeMap = new LinkedHashMap<>();

    static {
        apiReturnCodeMap.put(success, "成功");
        apiReturnCodeMap.put(failure, "失败");
        apiReturnCodeMap.put(failureParams, "请求参数错误");
        apiReturnCodeMap.put(repeatSubmitFailureParams, "请求过于频繁");
    }

    /**
     * 根据key返回描述信息
     *
     * @param key
     * @return
     */
    public static String getDescByKey(String key) {
        return apiReturnCodeMap.get(key);
    }

}
