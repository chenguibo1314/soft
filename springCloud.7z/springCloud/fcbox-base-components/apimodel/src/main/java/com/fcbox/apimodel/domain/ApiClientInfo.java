package com.fcbox.apimodel.domain;

import java.io.Serializable;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime: 2019/3/30 13:36
 * modifyTime:
 * modifyBy:
 */
public class ApiClientInfo implements Serializable {
    private static final long serialVersionUID = 6936454034616441072L;
    /**
     * 使用api的client的app的ip信息
     */
    private String clientAppIp;
    /**
     * 使用api的client的app名称
     */
    private String clientAppName;

    public ApiClientInfo() {
    }

    public String getClientAppIp() {
        return clientAppIp;
    }

    public void setClientAppIp(String clientAppIp) {
        this.clientAppIp = clientAppIp;
    }

    public String getClientAppName() {
        return clientAppName;
    }

    public void setClientAppName(String clientAppName) {
        this.clientAppName = clientAppName;
    }
}
