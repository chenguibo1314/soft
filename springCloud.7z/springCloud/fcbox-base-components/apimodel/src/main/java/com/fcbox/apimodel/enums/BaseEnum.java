package com.fcbox.apimodel.enums;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/19
 **/
@JsonSerialize(using = BaseEnumSerializer.class)
public interface BaseEnum<E extends Enum<?>, T> {

	/**
	 * 获取编码
	 */
	T getCode();  
	
	/**
	 * 文字描述
	 */
    String getDesc();  
    
    /**
     * 枚举类型
     */
    String getName();
}
