package com.fcbox.apimodel.enums;

/**
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/19
 **/
public enum DelFlag implements BaseEnum<DelFlag, Integer> {

    /**
     * 未删除
     */
    UNDEL(0, "未删除"),

    /**
     * 已删除
     */
    DEL(1, "已删除");

    /**
     * 编码
     */
    private int code;

    /**
     * 描述
     */
    private String desc;

    DelFlag(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public String getName() {
        return this.name();
    }

    public DelFlag enumValueOf(int code) {
        for (DelFlag enabled : DelFlag.values()) {
            if (enabled.getCode() == code) {
                return enabled;
            }
        }
        return null;
    }
}
