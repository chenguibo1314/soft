package com.fcbox.apimodel.response;

import com.fcbox.apimodel.domain.ApiResponseResult;
import com.fcbox.apimodel.enums.BaseApiCode;
import com.fcbox.apimodel.enums.ResultEnum;
import lombok.Data;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project:
 * copyright: TECHNOLOGY CO., LTD. (c) 2018-2025
 * createTime: 2019/1/30 13:01
 * modifyTime:
 * modifyBy:
 */
@Data
public class BaseResponse {

    protected ApiResponseResult success() {
        return new ApiResponseResult().success();
    }

    protected ApiResponseResult success(int code, String msg, Object data) {
        return new ApiResponseResult().success(code, msg, data);
    }

    protected ApiResponseResult success(String msg, Object data) {
        return success(BaseApiCode.SUCCESS.getCode(), msg, data);
    }

    protected ApiResponseResult success(Object data) {
        return success(BaseApiCode.SUCCESS.getCode(), null, data);
    }

    protected ApiResponseResult failure() {
        return new ApiResponseResult().failure();
    }

    protected ApiResponseResult failure(String msg) {
        return new ApiResponseResult().failure(msg);
    }

    protected ApiResponseResult failure(int code, String msg) {
        return new ApiResponseResult().failure(code, msg);
    }
    protected ApiResponseResult failure(ResultEnum<Integer> resultEnum) {
        return new ApiResponseResult().failure(resultEnum);
    }


}
