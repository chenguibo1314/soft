package com.fcbox.apimodel.domain;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;

import java.io.Serializable;
import java.util.Map;

/**
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createTime: 2019/3/30 13:37
 * modifyTime:
 * modifyBy:
 */
public class ApiResponseData implements Serializable {
    private static final long serialVersionUID = -166899791965821740L;
    /**
     * 属性
     */
    private Map<String, Object> attrs;
    /**
     * json数据
     */
    private String json;

    public ApiResponseData() {
    }

    /**
     * 通过 json 构造 ApiResponseData，注意返回结果不为 json 的 api（如果有的话）
     */
    @SuppressWarnings("unchecked")
    public ApiResponseData(String jsonStr) {
        this.json = jsonStr;

        try {
            Map<String, Object> temp = JSON.parseObject(jsonStr, Map.class);
            this.attrs = temp;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 通过 json 创建 ApiResponseData 对象，等价于 new ApiResponseData(jsonStr)
     */
    public static ApiResponseData create(String jsonStr) {
        return new ApiResponseData(jsonStr);
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this, SerializerFeature.DisableCircularReferenceDetect);
    }

    /**
     * 根据属性获取值
     *
     * @param name
     * @param <T>
     * @return
     */
    @SuppressWarnings("unchecked")
    public <T> T get(String name) {
        return (T) attrs.get(name);
    }

    public Map<String, Object> getAttrs() {
        return attrs;
    }

    public void setAttrs(Map<String, Object> attrs) {
        this.attrs = attrs;
    }

    public String getJson() {
        return json;
    }

    public void setJson(String json) {
        this.json = json;
    }

}
