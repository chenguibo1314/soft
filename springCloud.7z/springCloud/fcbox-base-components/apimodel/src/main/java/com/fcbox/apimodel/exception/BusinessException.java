package com.fcbox.apimodel.exception;


/**
 * 业务异常
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/19
 **/
@SuppressWarnings("serial")
public class BusinessException extends RuntimeException {

    /**
     * 异常编码
     */
    private int errorCode ;

    private Object data;


    public int getCode() {
        return this.errorCode;
    }

    public Object getData() {
        return this.data;
    }

    public BusinessException() {}

    public BusinessException(int errorCode, String message, Throwable cause) {
        this(message, cause);
        this.errorCode = errorCode;
    }

    public BusinessException(int errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }
    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }


    public BusinessException(Throwable cause) {
        super(cause.getMessage(), cause);
    }

    public BusinessException withData(Object data) {
        this.data = data;
        return this;
    }

}
