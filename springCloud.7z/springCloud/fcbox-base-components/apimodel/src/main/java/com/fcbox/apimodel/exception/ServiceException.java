package com.fcbox.apimodel.exception;

/**
 *服务异常
 * @author: Ningbo.Chen
 * @version: v1.0
 * @copyright: TECHNOLOGY CO., LTD. (c)2015-2025
 * @createTime: 2019/4/19
 **/
public class ServiceException extends Exception {

	private static final long serialVersionUID = -8336393496063368116L;

	private Integer errorCode;

	public ServiceException() {
	}

	public ServiceException(String msg) {
		super(msg);
	}

	public ServiceException(Throwable cause) {
		super(cause);
	}

	public ServiceException(String msg, Throwable cause) {
		super(msg, cause);
	}

	public ServiceException(int code, String msg) {
		super(msg);
		this.errorCode = code;
	}

	public ServiceException(int code, String msg, Throwable cause) {
		super(code + ":" + msg, cause);
		this.errorCode = code;
	}

	public int getErrorCode() {
		return this.errorCode;
	}
}