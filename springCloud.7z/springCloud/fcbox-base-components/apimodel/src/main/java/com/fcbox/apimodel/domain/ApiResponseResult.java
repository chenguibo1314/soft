package com.fcbox.apimodel.domain;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.fcbox.apimodel.enums.BaseApiCode;
import com.fcbox.apimodel.enums.ResultEnum;
import com.fcbox.apimodel.map.ApiReturnCodeMap;

import java.io.Serializable;

/**
 * api请求时返回的响应结果
 *
 * @version: v1.0
 * @author: Ningbo.Chen
 * project: fcbox-base-component
 * copyright:
 * createObjectime: 2019/3/30 13:37
 * modifyObjectime:
 * modifyBy:
 */
public class ApiResponseResult implements Serializable {
    private static final long serialVersionUID = 497819367022762513L;

    /**
     * 元数据，包括code、msg等信息（异常）
     */
    private ApiResponseMeta meta;
    /**
     * 具体的数据，可以为空{}
     */
    private Object data;

    public ApiResponseResult() {
    }

    /**
     * 仅返回成功
     *
     * @return
     */
    public ApiResponseResult success() {
        this.meta = new ApiResponseMeta(true, BaseApiCode.SUCCESS.getCode(), BaseApiCode.SUCCESS.getDesc());
        return this;
    }

    /**
     * 返回成功，并且返回code、msg和data
     *
     * @param data
     * @return
     */
    public ApiResponseResult success(int code, String msg, Object data) {
        this.meta = new ApiResponseMeta(true, code, msg);
        this.data = data;
        return this;
    }

    /**
     * 返回成功，并且返回msg和data
     *
     * @param msg
     * @param data
     * @return
     */
    public ApiResponseResult success(String msg, Object data) {
        this.meta = new ApiResponseMeta(true, BaseApiCode.SUCCESS.getCode(), msg);
        this.data = data;
        return this;
    }

    /**
     * 返回成功ok，并且返回data
     *
     * @param data
     * @return
     */
    public ApiResponseResult success(Object data) {
        this.meta = new ApiResponseMeta(true, BaseApiCode.SUCCESS.getCode(), BaseApiCode.SUCCESS.getDesc());
        this.data = data;
        return this;
    }

    /**
     * 仅返回失败error
     *
     * @return
     */
    public ApiResponseResult failure() {
        this.meta = new ApiResponseMeta(false, BaseApiCode.FAIL.getCode(), BaseApiCode.FAIL.getDesc());
        return this;
    }

    /**
     *
     * @return
     */
    public ApiResponseResult failureForParams() {
        this.meta = new ApiResponseMeta(false, BaseApiCode.PARAMETER_ERROR.getCode(), BaseApiCode.PARAMETER_ERROR.getDesc());
        return this;
    }

    /**
     * 返回失败error，并且返回msg
     *
     * @param msg
     * @return
     */
    public ApiResponseResult failure(String msg) {
        this.meta = new ApiResponseMeta(false, BaseApiCode.FAIL.getCode(), msg);
        return this;
    }

    /**
     * 返回失败error，并且返回code和msg
     *
     * @param code
     * @param msg
     * @return
     */
    public ApiResponseResult failure(int code, String msg) {
        this.meta = new ApiResponseMeta(false, code, msg);
        return this;
    }

    /**
     * 返回失败error
     *
     * @param resultEnum
     * @return
     */
    public ApiResponseResult failure(ResultEnum<Integer> resultEnum) {
        this.meta = new ApiResponseMeta(false, resultEnum.getCode(), resultEnum.getDesc());
        return this;
    }

    public ApiResponseMeta getMeta() {
        return meta;
    }

    public void setMeta(ApiResponseMeta meta) {
        this.meta = meta;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this, SerializerFeature.DisableCircularReferenceDetect);
    }
}
