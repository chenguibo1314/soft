 disconf-spring-boot-starter
===================================

### 使用步骤

* 在`spring boot`项目的`pom.xml`中添加以下依赖：

```xml
<dependency>
    <groupId>com.fcbox</groupId>
    <artifactId>disconf-spring-boot-starter</artifactId>
    <version>1.0.1</version>
</dependency>
```

```yml
spring:
  aop:
    #使你的项目支持 cglib的aop
    proxy-target-class: true
disconf:
  #disconf包扫描路径
  scanPackage: com.fcbox
  #不需要自动reload的配置文件
  unReloadFiles: myserver.properties
  #需要自动reload的配置文件
  files: autoconfig.properties,autoconfig2.properties,myserver_slave.properties,testJson.json,testXml2.xml
  #是否使用远程配置文件，true(默认)会从远程获取配置 false则直接获取本地配置
  enable:
	remote:
	  conf: true
  #配置服务器的 HOST(必填)，用逗号分隔  127.0.0.1:8000,127.0.0.1:8000
  conf_server_host: 127.0.0.1
  #APP 请采用 产品线_服务名 格式
  app: disconf-demo
  #环境
  env: rd
  #版本, 请采用 X_X_X_X 格式,注意要用单引号，不然Springboot将会解析成1000
  version: '1_0_0_0'
  #忽略哪些分布式配置，用逗号分隔
  ignore:
  #调试模式。调试模式下，ZK超时或断开连接后不会重新连接（常用于client单步debug）。非调试模式下，ZK超时或断开连接会自动重新连接。
  debug: false
  #获取远程配置 重试次数，默认是3次
  conf_server_url_retry_times: 1
  #获取远程配置 重试时休眠时间，默认是5秒
  conf_server_url_retry_sleep_seconds: 1
  #用户定义的下载文件夹, 远程文件下载后会放在这里。注意，此文件夹必须有有权限，否则无法下载到这里
  user_define_download_dir: /app/spring-boot/disconf/disconf-demo
  #下载的文件会被迁移到classpath根路径下(默认是false)
  enable_local_download_dir_in_class_path: false
```

<br/>
* 不需要动态推送配置写法<br/>
  * 添加disconf配置文件名到application.properties中的disconf.files配置项，多个文件用逗号分隔
  
  * 直接用@Value注释引用变量
  
  ```java
      @Value("${database.driverClassName}")
      private String driverClassName;
  ```
 
* 需要动态推送配置写法<br/>

```java
     @Service
     @Scope("singleton")
     @DisconfFile(filename = "app-conf.properties")
     public class AppConfig {
         /**
          * 配置项属性
          */
         private String property;
         
          @DisconfFileItem(name = "config", associateField = "property")
           public void setProperty(String property) {
               this.property = property;
           }
     }
  ```
    
* springboot原有starter中需要依赖disconf配置怎么办?比如redis等 
  * 直接在disconf上面配置springboot starter中要求的配置项即可
  ```java
  原理
  应用启动时，disconf starter
  从disconf服务器上拉取配置文件，下载到本地，并且解析文件中的变量注入到spring环境Environment中, 供依赖的springboot starter使用
  springboot在初始化starter中的配置类时，会循环读取Environment中包含的各个properties，有符合配置类的变量，就注入到相应配置类
  ```



